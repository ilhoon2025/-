-- 한국 수능 부정행위! : 클라이언트 UI (StarterPlayerScripts)
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local ContextActionService = game:GetService("ContextActionService")

local Shared = require(ReplicatedStorage:WaitForChild("SuneungShared"))
local remote = ReplicatedStorage:WaitForChild("SuneungEvent")
local player = Players.LocalPlayer
local camera = workspace.CurrentCamera

-------------------------------------------------------------------
-- 스타일
-------------------------------------------------------------------
local C = {
	surface = Color3.fromRGB(255, 255, 255),
	sub = Color3.fromRGB(246, 247, 249),
	line = Color3.fromRGB(226, 229, 234),
	text = Color3.fromRGB(31, 35, 40),
	muted = Color3.fromRGB(107, 114, 128),
	accent = Color3.fromRGB(30, 58, 138),
	danger = Color3.fromRGB(185, 28, 28),
	ok = Color3.fromRGB(21, 128, 61),
	paper = Color3.fromRGB(252, 251, 247),
}
local F = {
	reg = Enum.Font.Gotham,
	mid = Enum.Font.GothamMedium,
	bold = Enum.Font.GothamBold,
}

local function new(class, props, children)
	local o = Instance.new(class)
	for k, v in pairs(props) do
		if k ~= "Parent" then
			o[k] = v
		end
	end
	for _, ch in ipairs(children or {}) do
		ch.Parent = o
	end
	o.Parent = props.Parent
	return o
end
local function corner(r)
	return new("UICorner", { CornerRadius = UDim.new(0, r or 8) })
end
local function stroke(color, t)
	return new("UIStroke", { Color = color or C.line, Thickness = t or 1, ApplyStrokeMode = Enum.ApplyStrokeMode.Border })
end
local function pad(x, y)
	y = y or x
	return new("UIPadding", { PaddingTop = UDim.new(0, y), PaddingBottom = UDim.new(0, y), PaddingLeft = UDim.new(0, x), PaddingRight = UDim.new(0, x) })
end
local function text(props)
	props.BackgroundTransparency = props.BackgroundTransparency or 1
	props.Font = props.Font or F.reg
	props.TextSize = props.TextSize or 14
	props.TextColor3 = props.TextColor3 or C.text
	props.TextXAlignment = props.TextXAlignment or Enum.TextXAlignment.Left
	props.TextYAlignment = props.TextYAlignment or Enum.TextYAlignment.Center
	props.TextWrapped = true
	return new("TextLabel", props)
end
local function button(props, primary)
	props.Font = props.Font or F.bold
	props.TextSize = props.TextSize or 15
	props.AutoButtonColor = true
	if primary == false then
		props.BackgroundColor3 = props.BackgroundColor3 or C.surface
		props.TextColor3 = props.TextColor3 or C.text
		return new("TextButton", props, { corner(8), stroke() })
	end
	props.BackgroundColor3 = props.BackgroundColor3 or C.accent
	props.TextColor3 = props.TextColor3 or Color3.new(1, 1, 1)
	return new("TextButton", props, { corner(8) })
end
local function card(props)
	props.BackgroundColor3 = props.BackgroundColor3 or C.surface
	return new("Frame", props, { corner(12), stroke() })
end

-------------------------------------------------------------------
-- 화면 크기에 맞춰 UI 크기 자동 조절
-- 기준 해상도 1280x720 → 화면이 작으면 줄이고 크면 키움
-------------------------------------------------------------------
local gui = new("ScreenGui", { Name = "SuneungUI", ResetOnSpawn = false, IgnoreGuiInset = true, ZIndexBehavior = Enum.ZIndexBehavior.Sibling, Parent = player:WaitForChild("PlayerGui") })
local root = new("Frame", { Parent = gui, BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1) })
local uiScale = new("UIScale", { Parent = root })

local function fit()
	local v = camera.ViewportSize
	local s = math.clamp(math.min(v.X / 1280, v.Y / 720), 0.5, 1.6)
	uiScale.Scale = s
	root.Size = UDim2.fromOffset(v.X / s, v.Y / s)
end
camera:GetPropertyChangedSignal("ViewportSize"):Connect(fit)
fit()

-------------------------------------------------------------------
-- 처음 화면: 플레이하기를 눌러야 입장
-------------------------------------------------------------------
root.Visible = false
local title = new("Frame", { Parent = gui, BackgroundColor3 = Color3.fromRGB(15, 20, 35), BackgroundTransparency = 0.15, Size = UDim2.fromScale(1, 1), ZIndex = 200 })
text({ Parent = title, ZIndex = 201, Text = "한국 수능 부정행위", Font = F.bold, TextScaled = true, TextColor3 = Color3.new(1, 1, 1), TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.7, 0.12), Position = UDim2.fromScale(0.5, 0.34) })
text({ Parent = title, ZIndex = 201, Text = "감독관 몰래 부정행위로 1등급을 노려라. 들키면 가루가 된다.", TextScaled = true, TextColor3 = Color3.fromRGB(190, 200, 220), TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.6, 0.035), Position = UDim2.fromScale(0.5, 0.44) })
local playBtn = button({ Parent = title, ZIndex = 201, Text = "플레이하기", Font = F.bold, TextScaled = true, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.22, 0.09), Position = UDim2.fromScale(0.5, 0.6) })
new("UIPadding", { Parent = playBtn, PaddingTop = UDim.new(0.22, 0), PaddingBottom = UDim.new(0.22, 0) })
new("UISizeConstraint", { Parent = playBtn, MinSize = Vector2.new(180, 50), MaxSize = Vector2.new(360, 90) })

-- 처음 화면 동안은 학교 전경을 천천히 돌며 보여줌
camera.CameraType = Enum.CameraType.Scriptable
local spin = 0
local titleConn = RunService.RenderStepped:Connect(function(dt)
	spin = spin + dt * 0.05
	local center = Vector3.new(40, 0, 20)
	local eye = center + Vector3.new(math.cos(spin) * 170, 75, math.sin(spin) * 170)
	camera.CFrame = CFrame.lookAt(eye, center)
end)

playBtn.MouseButton1Click:Connect(function()
	titleConn:Disconnect()
	camera.CameraType = Enum.CameraType.Custom
	title:Destroy()
	root.Visible = true
	remote:FireServer("Play")
end)

-------------------------------------------------------------------
-- 상단 바
-------------------------------------------------------------------
local top = card({ Parent = root, Size = UDim2.new(1, -32, 0, 48), Position = UDim2.fromOffset(16, 12) })
text({ Parent = top, Text = "한국 수능 부정행위", Font = F.bold, TextSize = 18, Size = UDim2.new(0, 260, 1, 0), Position = UDim2.fromOffset(18, 0) })
local nukeBtn = button({ Parent = top, Text = "핵폭탄 발사", TextSize = 13, BackgroundColor3 = Color3.fromRGB(200, 30, 30), AnchorPoint = Vector2.new(0, 0.5), Size = UDim2.fromOffset(110, 32), Position = UDim2.new(0, 200, 0.5, 0) })
local floodBtn = button({ Parent = top, Text = "홍수", TextSize = 13, BackgroundColor3 = Color3.fromRGB(30, 110, 200), AnchorPoint = Vector2.new(0, 0.5), Size = UDim2.fromOffset(70, 32), Position = UDim2.new(0, 318, 0.5, 0) })
local poopBtn = button({ Parent = top, Text = "똥누기", TextSize = 13, BackgroundColor3 = Color3.fromRGB(120, 75, 30), AnchorPoint = Vector2.new(0, 0.5), Size = UDim2.fromOffset(80, 32), Position = UDim2.new(0, 396, 0.5, 0) })
local status = text({ Parent = top, Text = "대기 중", Font = F.mid, TextColor3 = C.muted, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(1, -640, 1, 0), Position = UDim2.new(0, 484, 0, 0) })
local moneyLabel = text({ Parent = top, Text = "", Font = F.bold, TextColor3 = C.text, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(0, 130, 1, 0), Position = UDim2.new(1, -148, 0, 0) })

-------------------------------------------------------------------
-- 왼쪽: 부정행위 적기
-------------------------------------------------------------------
local left = card({ Parent = root, Size = UDim2.new(0, 300, 1, -88), Position = UDim2.fromOffset(16, 72) })
pad(16).Parent = left

text({ Parent = left, Text = "부정행위 적기", Font = F.bold, TextSize = 17, Size = UDim2.new(1, 0, 0, 22) })
text({ Parent = left, Text = "세상에 있는 아무거나 적어 보세요. 적은 것마다 성공률과 적발 확률이 달라요.", TextSize = 12, TextColor3 = C.muted, Size = UDim2.new(1, 0, 0, 32), Position = UDim2.fromOffset(0, 26) })

local inputRow = new("Frame", { Parent = left, BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 38), Position = UDim2.fromOffset(0, 66) })
-- 키보드가 있으면 게임이 직접 키를 받아 한글을 조합하는 입력창, 터치 전용 기기는 일반 입력칸
local useCustomField = UserInputService.KeyboardEnabled
local field = button({ Parent = inputRow, Text = "", BackgroundColor3 = C.sub, Size = UDim2.new(1, -110, 1, 0), AutoButtonColor = false, Visible = useCustomField }, false)
field.BackgroundColor3 = C.sub
local fieldText = text({ Parent = field, Text = "", TextSize = 15, Size = UDim2.new(1, -20, 1, 0), Position = UDim2.fromOffset(10, 0), TextTruncate = Enum.TextTruncate.AtEnd })
local modeBtn = button({ Parent = inputRow, Text = "한", TextSize = 14, Size = UDim2.new(0, 40, 1, 0), Position = UDim2.new(1, -104, 0, 0), Visible = useCustomField }, false)
local input = new("TextBox", {
	Parent = inputRow,
	Size = UDim2.new(1, -66, 1, 0),
	BackgroundColor3 = C.sub,
	Text = "",
	PlaceholderText = "예) 스마트워치, 지우개",
	PlaceholderColor3 = C.muted,
	TextColor3 = C.text,
	Font = F.reg,
	TextSize = 15,
	ClearTextOnFocus = false,
	TextXAlignment = Enum.TextXAlignment.Left,
	TextTruncate = Enum.TextTruncate.AtEnd,
	Visible = not useCustomField,
}, { corner(8), stroke(), pad(10, 0) })
local addBtn = button({ Parent = inputRow, Text = "추가", Size = UDim2.new(0, 58, 1, 0), Position = UDim2.new(1, -58, 0, 0) })

local listTop = 116
local actionH = 240
local list = new("ScrollingFrame", { Parent = left, BackgroundTransparency = 1, BorderSizePixel = 0, Size = UDim2.new(1, 0, 1, -(listTop + actionH + 10)), Position = UDim2.fromOffset(0, listTop), CanvasSize = UDim2.new(), AutomaticCanvasSize = Enum.AutomaticSize.Y, ScrollBarThickness = 3, ScrollBarImageColor3 = C.line })
new("UIListLayout", { Parent = list, Padding = UDim.new(0, 6), SortOrder = Enum.SortOrder.LayoutOrder })

-- 아래쪽 동작 영역
local action = new("Frame", { Parent = left, BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, actionH), Position = UDim2.new(0, 0, 1, -actionH) })
new("Frame", { Parent = action, BackgroundColor3 = C.line, BorderSizePixel = 0, Size = UDim2.new(1, 0, 0, 1) })
local curLabel = text({ Parent = action, Text = "선택: -", Font = F.mid, TextSize = 13, TextColor3 = C.muted, Size = UDim2.new(1, 0, 0, 20), Position = UDim2.fromOffset(0, 12), TextTruncate = Enum.TextTruncate.AtEnd })
local startBtn = button({ Parent = action, Text = "시험 시작", TextSize = 16, Size = UDim2.new(1, 0, 0, 44), Position = UDim2.fromOffset(0, 38) })
local cheatBtn = button({ Parent = action, Text = "부정행위 시도", TextSize = 16, BackgroundColor3 = C.danger, Size = UDim2.new(1, 0, 0, 44), Position = UDim2.fromOffset(0, 38), Visible = false })
local leaveBtn = button({ Parent = action, Text = "몰래 나가기", TextSize = 14, Size = UDim2.new(1, 0, 0, 36), Position = UDim2.fromOffset(0, 88), Visible = false }, false)
local progBg = new("Frame", { Parent = action, BackgroundColor3 = C.sub, Size = UDim2.new(1, 0, 0, 6), Position = UDim2.fromOffset(0, 132), Visible = false }, { corner(3) })
local progFill = new("Frame", { Parent = progBg, BackgroundColor3 = C.danger, Size = UDim2.new(0, 0, 1, 0) }, { corner(3) })
local hintLabel = text({ Parent = action, Text = "", Font = F.mid, TextSize = 13, Size = UDim2.new(1, 0, 0, 40), Position = UDim2.fromOffset(0, 144), TextYAlignment = Enum.TextYAlignment.Top })
local logLabel = text({ Parent = action, Text = "", TextSize = 12, TextColor3 = C.muted, Size = UDim2.new(1, 0, 0, 50), Position = UDim2.fromOffset(0, 188), TextYAlignment = Enum.TextYAlignment.Top })

-------------------------------------------------------------------
-- 오른쪽 아래: 시험지
-------------------------------------------------------------------
local paper = card({ Parent = root, BackgroundColor3 = C.paper, AnchorPoint = Vector2.new(1, 1), Size = UDim2.fromOffset(460, 430), Position = UDim2.new(1, -16, 1, -16), Visible = false })
pad(22, 18).Parent = paper
local paperHead = text({ Parent = paper, Text = "2027학년도 대학수학능력시험", Font = F.mid, TextSize = 12, TextColor3 = C.muted, Size = UDim2.new(1, 0, 0, 16) })
local paperNum = text({ Parent = paper, Text = "", Font = F.mid, TextSize = 12, TextColor3 = C.muted, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(1, 0, 0, 16) })
new("Frame", { Parent = paper, BackgroundColor3 = C.text, BorderSizePixel = 0, Size = UDim2.new(1, 0, 0, 2), Position = UDim2.fromOffset(0, 24) })
local qLabel = text({ Parent = paper, Text = "", Font = F.bold, TextSize = 18, Size = UDim2.new(1, 0, 0, 52), Position = UDim2.fromOffset(0, 36), TextYAlignment = Enum.TextYAlignment.Top })

local choiceBtns = {}
local picked = nil
for i = 1, 5 do
	local b = new("TextButton", {
		Parent = paper,
		Text = "",
		Font = F.reg,
		TextSize = 16,
		TextColor3 = C.text,
		TextXAlignment = Enum.TextXAlignment.Left,
		BackgroundColor3 = C.paper,
		AutoButtonColor = false,
		Size = UDim2.new(1, 0, 0, 40),
		Position = UDim2.fromOffset(0, 94 + (i - 1) * 46),
	}, { corner(8), pad(12, 0) })
	local st = stroke(C.line, 1)
	st.Parent = b
	b.MouseButton1Click:Connect(function()
		picked = i
		for j, other in ipairs(choiceBtns) do
			local on = j == i
			other.BackgroundColor3 = on and Color3.fromRGB(232, 237, 250) or C.paper
			other.UIStroke.Color = on and C.accent or C.line
			other.UIStroke.Thickness = on and 2 or 1
		end
	end)
	choiceBtns[i] = b
end
local submitBtn = button({ Parent = paper, Text = "답안 제출", TextSize = 16, AnchorPoint = Vector2.new(1, 1), Size = UDim2.fromOffset(140, 42), Position = UDim2.fromScale(1, 1) })
local paperMsg = text({ Parent = paper, Text = "", TextSize = 13, TextColor3 = C.danger, AnchorPoint = Vector2.new(0, 1), Size = UDim2.new(1, -150, 0, 42), Position = UDim2.fromScale(0, 1) })

-------------------------------------------------------------------
-- 영역전개 (배경 없이 사진과 대사만)
-------------------------------------------------------------------
local domain = new("Frame", { Parent = root, BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1), ZIndex = 50, Visible = false })
local domainImg = new("ImageLabel", { Parent = domain, ZIndex = 51, Image = Shared.DOMAIN_IMAGE, BackgroundTransparency = 1, ScaleType = Enum.ScaleType.Fit, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.4, 0.45), Position = UDim2.fromScale(0.5, 0.42) })
local domainText = text({ Parent = domain, ZIndex = 52, Text = Shared.DOMAIN_LINE, Font = F.bold, TextSize = 48, TextColor3 = Color3.new(1, 1, 1), TextStrokeColor3 = Color3.fromRGB(20, 40, 90), TextStrokeTransparency = 0, TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.new(1, -40, 0, 60), Position = UDim2.fromScale(0.5, 0.7) })
local domainWho = text({ Parent = domain, ZIndex = 52, Text = "", Font = F.bold, TextSize = 20, TextColor3 = Color3.new(1, 1, 1), TextStrokeTransparency = 0.2, TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.new(1, -40, 0, 28), Position = UDim2.fromScale(0.5, 0.8) })

-------------------------------------------------------------------
-- 가방 (오른쪽 위)
-------------------------------------------------------------------
local bag = card({ Parent = root, AnchorPoint = Vector2.new(1, 0), Size = UDim2.fromOffset(260, 180), Position = UDim2.new(1, -16, 0, 72) })
pad(14, 12).Parent = bag
text({ Parent = bag, Text = "가방", Font = F.bold, TextSize = 15, Size = UDim2.new(1, 0, 0, 20) })
local bagEmpty = text({ Parent = bag, Text = "비어 있음. 교실 밖 도로 건너 매점에서 살 수 있어요.", TextSize = 12, TextColor3 = C.muted, Size = UDim2.new(1, 0, 0, 34), Position = UDim2.fromOffset(0, 26) })
local bagList = new("ScrollingFrame", { Parent = bag, BackgroundTransparency = 1, BorderSizePixel = 0, Size = UDim2.new(1, 0, 1, -26), Position = UDim2.fromOffset(0, 26), CanvasSize = UDim2.new(), AutomaticCanvasSize = Enum.AutomaticSize.Y, ScrollBarThickness = 3, ScrollBarImageColor3 = C.line })
new("UIListLayout", { Parent = bagList, Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.LayoutOrder })

-------------------------------------------------------------------
-- 매점 창
-------------------------------------------------------------------
local shop = new("Frame", { Parent = root, BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 0.5, Size = UDim2.fromScale(1, 1), ZIndex = 30, Visible = false })
local shopBox = card({ Parent = shop, ZIndex = 31, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(460, 420) })
pad(20).Parent = shopBox
text({ Parent = shopBox, ZIndex = 32, Text = "매점", Font = F.bold, TextSize = 20, Size = UDim2.new(1, 0, 0, 26) })
local shopMoney = text({ Parent = shopBox, ZIndex = 32, Text = "", Font = F.mid, TextSize = 14, TextColor3 = C.muted, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(1, -40, 0, 26) })
local shopClose = button({ Parent = shopBox, ZIndex = 32, Text = "X", TextSize = 14, AnchorPoint = Vector2.new(1, 0), Size = UDim2.fromOffset(28, 26), Position = UDim2.fromScale(1, 0) }, false)
for i, it in ipairs(Shared.SHOP) do
	local row = new("Frame", { Parent = shopBox, ZIndex = 32, BackgroundColor3 = C.sub, Size = UDim2.new(1, 0, 0, 52), Position = UDim2.fromOffset(0, 38 + (i - 1) * 58) }, { corner(8) })
	text({ Parent = row, ZIndex = 33, Text = it.name, Font = F.bold, TextSize = 15, Size = UDim2.new(1, -200, 0, 20), Position = UDim2.fromOffset(12, 7) })
	text({ Parent = row, ZIndex = 33, Text = it.desc, TextSize = 12, TextColor3 = C.muted, Size = UDim2.new(1, -200, 0, 16), Position = UDim2.fromOffset(12, 28) })
	text({ Parent = row, ZIndex = 33, Text = it.price .. "원", Font = F.mid, TextSize = 14, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.fromOffset(80, 52), Position = UDim2.new(1, -172, 0, 0) })
	local buy = button({ Parent = row, ZIndex = 33, Text = "구매", TextSize = 14, AnchorPoint = Vector2.new(1, 0.5), Size = UDim2.fromOffset(72, 34), Position = UDim2.new(1, -10, 0.5, 0) })
	buy.MouseButton1Click:Connect(function()
		remote:FireServer("Buy", it.id)
	end)
end
shopClose.MouseButton1Click:Connect(function()
	shop.Visible = false
end)

-------------------------------------------------------------------
-- 부정행위 전문점 창
-------------------------------------------------------------------
local proShop = new("Frame", { Parent = root, BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 0.5, Size = UDim2.fromScale(1, 1), ZIndex = 30, Visible = false })
local proBox = card({ Parent = proShop, ZIndex = 31, BackgroundColor3 = Color3.fromRGB(24, 22, 34), AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(560, 600) })
proBox.UIStroke.Color = Color3.fromRGB(150, 90, 240)
pad(20).Parent = proBox
local PRO_TEXT = Color3.fromRGB(235, 230, 250)
local PRO_MUTED = Color3.fromRGB(160, 150, 190)
local PRO_ACCENT = Color3.fromRGB(150, 90, 240)
text({ Parent = proBox, ZIndex = 32, Text = "부정행위 전문점", Font = F.bold, TextSize = 20, TextColor3 = PRO_TEXT, Size = UDim2.new(1, 0, 0, 26) })
text({ Parent = proBox, ZIndex = 32, Text = "세상의 모든 전자기기. 정품은 성공률 +25%, 적발 확률 -15%", TextSize = 12, TextColor3 = PRO_MUTED, Size = UDim2.new(1, 0, 0, 16), Position = UDim2.fromOffset(0, 28) })
local proMoney = text({ Parent = proBox, ZIndex = 32, Text = "", Font = F.mid, TextSize = 14, TextColor3 = PRO_MUTED, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(1, -40, 0, 26) })
local proClose = button({ Parent = proBox, ZIndex = 32, Text = "X", TextSize = 14, AnchorPoint = Vector2.new(1, 0), Size = UDim2.fromOffset(28, 26), Position = UDim2.fromScale(1, 0) }, false)

-- 맞춤 제작: 왼쪽 목록에서 고른 물건을 그대로 주문
local custom = new("Frame", { Parent = proBox, ZIndex = 32, BackgroundColor3 = Color3.fromRGB(40, 32, 62), Size = UDim2.new(1, 0, 0, 58), Position = UDim2.fromOffset(0, 54) }, { corner(8) })
text({ Parent = custom, ZIndex = 33, Text = "맞춤 제작", Font = F.bold, TextSize = 13, TextColor3 = Color3.fromRGB(200, 170, 255), Size = UDim2.new(1, -140, 0, 18), Position = UDim2.fromOffset(12, 8) })
local customName = text({ Parent = custom, ZIndex = 33, Text = "", Font = F.mid, TextSize = 13, TextColor3 = PRO_TEXT, Size = UDim2.new(1, -140, 0, 22), Position = UDim2.fromOffset(12, 28), TextTruncate = Enum.TextTruncate.AtEnd })
local customBtn = button({ Parent = custom, ZIndex = 33, Text = "주문", TextSize = 14, BackgroundColor3 = PRO_ACCENT, AnchorPoint = Vector2.new(1, 0.5), Size = UDim2.fromOffset(110, 38), Position = UDim2.new(1, -10, 0.5, 0) })

local proList = new("ScrollingFrame", { Parent = proBox, ZIndex = 32, BackgroundTransparency = 1, BorderSizePixel = 0, Size = UDim2.new(1, 0, 1, -124), Position = UDim2.fromOffset(0, 124), CanvasSize = UDim2.new(), AutomaticCanvasSize = Enum.AutomaticSize.Y, ScrollBarThickness = 4, ScrollBarImageColor3 = PRO_ACCENT })
new("UIGridLayout", { Parent = proList, CellSize = UDim2.new(0.5, -6, 0, 50), CellPadding = UDim2.fromOffset(8, 8), SortOrder = Enum.SortOrder.LayoutOrder })
local owned = {}
local proButtons = {}
for i, it in ipairs(Shared.PRO) do
	local row = new("Frame", { Parent = proList, ZIndex = 33, LayoutOrder = i, BackgroundColor3 = Color3.fromRGB(36, 32, 52) }, { corner(8) })
	text({ Parent = row, ZIndex = 34, Text = it.name, Font = F.bold, TextSize = 13, TextColor3 = PRO_TEXT, Size = UDim2.new(1, -86, 0, 18), Position = UDim2.fromOffset(10, 7), TextTruncate = Enum.TextTruncate.AtEnd })
	local priceLabel = text({ Parent = row, ZIndex = 34, Text = it.price .. "원", TextSize = 12, TextColor3 = PRO_MUTED, Size = UDim2.new(1, -86, 0, 16), Position = UDim2.fromOffset(10, 27) })
	local b = button({ Parent = row, ZIndex = 34, Text = "구매", TextSize = 13, BackgroundColor3 = PRO_ACCENT, AnchorPoint = Vector2.new(1, 0.5), Size = UDim2.fromOffset(66, 32), Position = UDim2.new(1, -8, 0.5, 0) })
	b.MouseButton1Click:Connect(function()
		if not owned[it.name] then
			remote:FireServer("BuyPro", it.name)
		end
	end)
	proButtons[it.name] = { button = b, price = priceLabel, base = it.price }
end
local proBought = 0 -- 전문점에서 산 횟수 (갈수록 2배)
local function refreshProButtons()
	for name, e in pairs(proButtons) do
		local has = owned[name]
		e.button.Text = has and "보유" or "구매"
		e.button.BackgroundColor3 = has and Color3.fromRGB(70, 70, 85) or PRO_ACCENT
		e.price.Text = has and "보유 중" or (Shared.doubled(e.base, proBought) .. "원")
	end
end
proClose.MouseButton1Click:Connect(function()
	proShop.Visible = false
end)
-- customBtn 은 cheats 가 정의된 뒤에 연결 (아래)

-------------------------------------------------------------------
-- 업그레이드 전문점 창
-------------------------------------------------------------------
local gearLv = {} -- [부정행위 이름] = 강화 단계
local perkLv = {} -- stealth / poker / quick
local UP_ACCENT = Color3.fromRGB(14, 140, 180)
local upShop = new("Frame", { Parent = root, BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 0.5, Size = UDim2.fromScale(1, 1), ZIndex = 30, Visible = false })
local upBox = card({ Parent = upShop, ZIndex = 31, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(500, 400) })
upBox.UIStroke.Color = UP_ACCENT
pad(20).Parent = upBox
text({ Parent = upBox, ZIndex = 32, Text = "업그레이드 전문점", Font = F.bold, TextSize = 20, Size = UDim2.new(1, 0, 0, 26) })
text({ Parent = upBox, ZIndex = 32, Text = "단계가 오를 때마다 가격이 2배가 됩니다.", TextSize = 12, TextColor3 = C.muted, Size = UDim2.new(1, 0, 0, 16), Position = UDim2.fromOffset(0, 28) })
local upMoney = text({ Parent = upBox, ZIndex = 32, Text = "", Font = F.mid, TextSize = 14, TextColor3 = C.muted, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(1, -40, 0, 26) })
local upClose = button({ Parent = upBox, ZIndex = 32, Text = "X", TextSize = 14, AnchorPoint = Vector2.new(1, 0), Size = UDim2.fromOffset(28, 26), Position = UDim2.fromScale(1, 0) }, false)
upClose.MouseButton1Click:Connect(function()
	upShop.Visible = false
end)
local upRows = {}
for i, u in ipairs(Shared.UPGRADES) do
	local row = new("Frame", { Parent = upBox, ZIndex = 32, BackgroundColor3 = C.sub, Size = UDim2.new(1, 0, 0, 70), Position = UDim2.fromOffset(0, 56 + (i - 1) * 78) }, { corner(8) })
	local title = text({ Parent = row, ZIndex = 33, Text = u.name, Font = F.bold, TextSize = 15, Size = UDim2.new(1, -140, 0, 20), Position = UDim2.fromOffset(12, 8), TextTruncate = Enum.TextTruncate.AtEnd })
	text({ Parent = row, ZIndex = 33, Text = u.desc, TextSize = 12, TextColor3 = C.muted, Size = UDim2.new(1, -140, 0, 16), Position = UDim2.fromOffset(12, 30) })
	local info = text({ Parent = row, ZIndex = 33, Text = "", Font = F.mid, TextSize = 12, TextColor3 = UP_ACCENT, Size = UDim2.new(1, -140, 0, 16), Position = UDim2.fromOffset(12, 48) })
	local b = button({ Parent = row, ZIndex = 33, Text = "강화", TextSize = 14, BackgroundColor3 = UP_ACCENT, AnchorPoint = Vector2.new(1, 0.5), Size = UDim2.fromOffset(110, 40), Position = UDim2.new(1, -12, 0.5, 0) })
	upRows[u.id] = { title = title, info = info, button = b, def = u }
end

-------------------------------------------------------------------
-- 알림
-------------------------------------------------------------------
local toastLabel = text({ Parent = root, ZIndex = 60, Text = "", Font = F.mid, TextSize = 15, TextColor3 = Color3.new(1, 1, 1), BackgroundTransparency = 0.15, BackgroundColor3 = Color3.fromRGB(31, 35, 40), TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.fromOffset(420, 40), Position = UDim2.new(0.5, 0, 0, 72), Visible = false })
corner(8).Parent = toastLabel
local toastId = 0
local function toast(msg)
	toastId = toastId + 1
	local my = toastId
	toastLabel.Text = msg
	toastLabel.Visible = true
	task.delay(2.5, function()
		if toastId == my then
			toastLabel.Visible = false
		end
	end)
end

-------------------------------------------------------------------
-- 부정행위 물건 화면 (스마트워치면 스마트워치 화면에 정답이 뜸)
-------------------------------------------------------------------
local KINDS = {
	{ kind = "watch", words = { "워치", "시계", "watch" } },
	{ kind = "phone", words = { "폰", "핸드폰", "휴대폰", "아이패드", "태블릿", "phone" } },
	{ kind = "calc", words = { "계산기" } },
	{ kind = "palm", words = { "손바닥", "손", "팔" } },
	{ kind = "eraser", words = { "지우개" } },
	{ kind = "note", words = { "쪽지", "메모", "종이", "커닝페이퍼", "포스트잇", "필기" } },
	{ kind = "earbud", words = { "이어폰", "이어버드", "무전기", "스피커", "녹음기", "mp3", "귀" } },
	{ kind = "glasses", words = { "안경", "렌즈", "vr", "디스플레이", "카메라", "헤드셋" } },
}
local function kindOf(name, isCopy)
	if isCopy then
		return "neighbor"
	end
	for _, k in ipairs(KINDS) do
		for _, w in ipairs(k.words) do
			if string.find(string.lower(name), w, 1, true) then
				return k.kind
			end
		end
	end
	return "generic"
end

local viewHolder = new("Frame", { Parent = root, BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 1), Size = UDim2.fromOffset(320, 400), Position = UDim2.new(0.5, 0, 1, 420), ZIndex = 20 })
local viewId = 0

local function z(o, n)
	o.ZIndex = n
	return o
end
local function rect(parent, color, size, pos, r, zi, props)
	props = props or {}
	props.Parent = parent
	props.BackgroundColor3 = color
	props.Size = size
	props.Position = pos
	props.AnchorPoint = props.AnchorPoint or Vector2.new(0.5, 0.5)
	props.ZIndex = zi or 21
	props.BorderSizePixel = 0
	local f = new("Frame", props)
	if r then
		corner(r).Parent = f
	end
	return f
end
local function txt(parent, str, size, color, pos, zi, font, sz)
	return text({ Parent = parent, Text = str, TextSize = size, TextColor3 = color, Font = font or F.bold, TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0.5), Position = pos, Size = sz or UDim2.new(1, -20, 0, size + 8), ZIndex = zi or 25 })
end

local function buildView(kind, name, ans, extra)
	local h = viewHolder
	for _, ch in ipairs(h:GetChildren()) do
		ch:Destroy()
	end
	local num = Shared.NUM[ans] or "?"
	local qn = extra.q or 0
	local center = UDim2.fromScale(0.5, 0.5)
	if kind == "watch" then
		rect(h, Color3.fromRGB(40, 42, 48), UDim2.fromOffset(120, 400), center, 24, 21)
		local case = rect(h, Color3.fromRGB(70, 72, 80), UDim2.fromOffset(230, 250), center, 60, 22)
		rect(case, Color3.fromRGB(90, 92, 100), UDim2.fromOffset(14, 46), UDim2.new(1, 4, 0.4, 0), 6, 21)
		local screen = rect(case, Color3.fromRGB(5, 5, 8), UDim2.new(1, -24, 1, -24), center, 50, 23)
		txt(screen, os.date("%H:%M"), 16, Color3.fromRGB(160, 160, 170), UDim2.fromScale(0.5, 0.17), 25, F.mid)
		txt(screen, qn .. "번 정답", 14, Color3.fromRGB(120, 200, 255), UDim2.fromScale(0.5, 0.32), 25, F.mid)
		txt(screen, num, 84, Color3.fromRGB(120, 255, 170), UDim2.fromScale(0.5, 0.62), 25, F.bold, UDim2.new(1, 0, 0, 90))
		rect(screen, Color3.fromRGB(120, 255, 170), UDim2.fromOffset(60, 4), UDim2.fromScale(0.5, 0.88), 2, 25)
	elseif kind == "phone" then
		local body = rect(h, Color3.fromRGB(20, 20, 24), UDim2.fromOffset(210, 390), center, 32, 21)
		local screen = rect(body, Color3.fromRGB(28, 44, 80), UDim2.new(1, -16, 1, -16), center, 26, 22)
		rect(screen, Color3.fromRGB(10, 10, 12), UDim2.fromOffset(70, 18), UDim2.new(0.5, 0, 0, 16), 9, 23)
		txt(screen, os.date("%H:%M"), 40, Color3.new(1, 1, 1), UDim2.fromScale(0.5, 0.2), 24, F.bold)
		local bubble = rect(screen, Color3.fromRGB(245, 245, 248), UDim2.new(1, -24, 0, 110), UDim2.fromScale(0.5, 0.55), 16, 24)
		text({ Parent = bubble, Text = "메시지 · 지금", TextSize = 12, TextColor3 = C.muted, Size = UDim2.new(1, -24, 0, 16), Position = UDim2.fromOffset(12, 10), ZIndex = 25 })
		text({ Parent = bubble, Text = "답 알려줄게", Font = F.bold, TextSize = 14, Size = UDim2.new(1, -24, 0, 18), Position = UDim2.fromOffset(12, 30), ZIndex = 25 })
		text({ Parent = bubble, Text = qn .. "번 정답 " .. num, Font = F.bold, TextSize = 26, TextColor3 = C.accent, Size = UDim2.new(1, -24, 0, 34), Position = UDim2.fromOffset(12, 56), ZIndex = 25 })
	elseif kind == "calc" then
		local body = rect(h, Color3.fromRGB(50, 52, 58), UDim2.fromOffset(220, 340), center, 18, 21)
		local disp = rect(body, Color3.fromRGB(170, 190, 150), UDim2.new(1, -30, 0, 80), UDim2.new(0.5, 0, 0, 60), 6, 22)
		text({ Parent = disp, Text = qn .. "번=" .. ans, Font = Enum.Font.Code, TextSize = 40, TextColor3 = Color3.fromRGB(30, 40, 30), TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(1, -16, 1, 0), Position = UDim2.fromOffset(8, 0), ZIndex = 23 })
		for r = 0, 3 do
			for c = 0, 3 do
				local k = rect(body, Color3.fromRGB(90, 92, 100), UDim2.fromOffset(38, 34), UDim2.new(0, 38 + c * 48, 0, 140 + r * 46), 6, 22)
				k.AnchorPoint = Vector2.new(0.5, 0.5)
			end
		end
	elseif kind == "palm" then
		local skin = Color3.fromRGB(240, 200, 170)
		for i2, off in ipairs({ -66, -22, 22, 66 }) do
			rect(h, skin, UDim2.fromOffset(40, 130 + ((i2 == 2 or i2 == 3) and 20 or 0)), UDim2.new(0.5, off, 0.5, -150), 20, 21)
		end
		rect(h, skin, UDim2.fromOffset(40, 120), UDim2.new(0.5, -120, 0.5, 10), 20, 21).Rotation = -35
		local palm = rect(h, skin, UDim2.fromOffset(200, 230), UDim2.new(0.5, 0, 0.5, 20), 90, 22)
		local ink = txt(palm, qn .. "번 " .. num, 44, Color3.fromRGB(30, 60, 170), UDim2.fromScale(0.5, 0.45), 24, F.bold, UDim2.new(1, 0, 0, 60))
		ink.Rotation = -8
		local ink2 = txt(palm, "정답!!", 22, Color3.fromRGB(30, 60, 170), UDim2.fromScale(0.5, 0.7), 24, F.mid)
		ink2.Rotation = -6
	elseif kind == "eraser" then
		local e = rect(h, Color3.fromRGB(250, 250, 250), UDim2.fromOffset(260, 140), center, 14, 21)
		e.Rotation = -6
		stroke(C.line, 1).Parent = e
		local sleeve = rect(e, Color3.fromRGB(40, 90, 190), UDim2.new(0.5, 0, 1, 0), UDim2.fromScale(0.7, 0.5), nil, 22)
		txt(sleeve, "ERASER", 18, Color3.new(1, 1, 1), UDim2.fromScale(0.5, 0.5), 23)
		local w = txt(e, qn .. "번 " .. num, 34, Color3.fromRGB(60, 60, 60), UDim2.fromScale(0.25, 0.5), 23, F.mid, UDim2.new(0.5, 0, 0, 44))
		w.Rotation = 4
	elseif kind == "note" then
		local n = rect(h, Color3.fromRGB(255, 244, 150), UDim2.fromOffset(250, 250), center, 4, 21)
		n.Rotation = 4
		for i2 = 1, 6 do
			rect(n, Color3.fromRGB(230, 210, 110), UDim2.new(1, -30, 0, 1), UDim2.new(0.5, 0, 0, 40 + i2 * 30), nil, 22)
		end
		txt(n, "커닝 쪽지", 16, Color3.fromRGB(120, 100, 30), UDim2.fromScale(0.5, 0.12), 23, F.mid)
		txt(n, qn .. "번 → " .. num, 46, Color3.fromRGB(40, 40, 40), UDim2.fromScale(0.5, 0.5), 23, F.bold, UDim2.new(1, 0, 0, 56))
	elseif kind == "neighbor" then
		local p = rect(h, C.paper, UDim2.fromOffset(280, 300), center, 6, 21)
		p.Rotation = -5
		stroke(C.line, 1).Parent = p
		txt(p, (extra.seat or "?") .. "번 자리 답안지", 16, C.muted, UDim2.fromScale(0.5, 0.1), 23, F.mid)
		for i2 = 1, 5 do
			local y = 0.25 + (i2 - 1) * 0.14
			txt(p, Shared.NUM[i2], 26, C.text, UDim2.fromScale(0.5, y), 23, F.reg, UDim2.fromOffset(40, 34))
			if i2 == ans then
				local circle = rect(p, Color3.new(1, 1, 1), UDim2.fromOffset(44, 44), UDim2.fromScale(0.5, y), 22, 22, { BackgroundTransparency = 1 })
				stroke(C.danger, 3).Parent = circle
			end
		end
		txt(p, qn .. "번 문제", 14, C.muted, UDim2.fromScale(0.5, 0.95), 23, F.mid)
	elseif kind == "earbud" then
		local bud = rect(h, Color3.fromRGB(245, 245, 248), UDim2.fromOffset(90, 90), UDim2.new(0.5, 0, 1, -60), 45, 22)
		stroke(C.line, 1).Parent = bud
		rect(bud, Color3.fromRGB(40, 40, 45), UDim2.fromOffset(34, 34), center, 17, 23)
		for k = 1, 3 do
			local wave = rect(h, Color3.new(1, 1, 1), UDim2.fromOffset(90 + k * 50, 90 + k * 50), UDim2.new(0.5, 0, 1, -60), 200, 21, { BackgroundTransparency = 1 })
			stroke(Color3.fromRGB(120, 200, 255), 3).Parent = wave
			wave.UIStroke.Transparency = 0.2 + k * 0.2
		end
		local bubble = rect(h, Color3.fromRGB(20, 24, 36), UDim2.fromOffset(280, 110), UDim2.new(0.5, 0, 0, 80), 16, 24)
		txt(bubble, "(속삭임)", 13, Color3.fromRGB(150, 170, 200), UDim2.fromScale(0.5, 0.2), 25, F.mid)
		txt(bubble, qn .. "번… 정답은 " .. num, 30, Color3.fromRGB(120, 220, 255), UDim2.fromScale(0.5, 0.62), 25, F.bold, UDim2.new(1, 0, 0, 40))
	elseif kind == "glasses" then
		local frameC = Color3.fromRGB(25, 25, 30)
		for _, off in ipairs({ -78, 78 }) do
			local lens = rect(h, Color3.fromRGB(120, 200, 255), UDim2.fromOffset(140, 110), UDim2.new(0.5, off, 0.5, 0), 40, 22, { BackgroundTransparency = 0.55 })
			stroke(frameC, 8).Parent = lens
		end
		rect(h, frameC, UDim2.fromOffset(30, 8), UDim2.new(0.5, 0, 0.5, -20), 4, 23)
		local hud = txt(h, qn .. "번 정답 " .. num, 30, Color3.fromRGB(120, 255, 170), UDim2.new(0.5, 78, 0.5, 0), 25, F.bold, UDim2.fromOffset(140, 40))
		hud.TextScaled = true
		txt(h, "HUD", 12, Color3.fromRGB(120, 255, 170), UDim2.new(0.5, 78, 0.5, -36), 25, F.mid, UDim2.fromOffset(140, 16))
	else
		local c2 = rect(h, C.surface, UDim2.fromOffset(260, 220), center, 18, 21)
		stroke(C.line, 1).Parent = c2
		txt(c2, name, 20, C.text, UDim2.fromScale(0.5, 0.18), 23, F.bold)
		txt(c2, "이(가) 속삭인다…", 13, C.muted, UDim2.fromScale(0.5, 0.32), 23, F.mid)
		txt(c2, qn .. "번 정답 " .. num, 40, C.accent, UDim2.fromScale(0.5, 0.65), 23, F.bold, UDim2.new(1, 0, 0, 50))
	end
end

local function showCheatView(name, isCopy, ans, extra)
	viewId = viewId + 1
	local my = viewId
	buildView(kindOf(name, isCopy), name, ans, extra)
	viewHolder.Position = UDim2.new(0.5, 0, 1, 420)
	TweenService:Create(viewHolder, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Position = UDim2.new(0.5, 0, 1, -20) }):Play()
	task.delay(4, function()
		if viewId == my then
			TweenService:Create(viewHolder, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Position = UDim2.new(0.5, 0, 1, 420) }):Play()
		end
	end)
end

-------------------------------------------------------------------
-- 결과창
-------------------------------------------------------------------
local modal = new("Frame", { Parent = root, BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 0.5, Size = UDim2.fromScale(1, 1), ZIndex = 40, Visible = false })
local box = card({ Parent = modal, ZIndex = 41, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(380, 280) })
pad(24).Parent = box
local mTitle = text({ Parent = box, ZIndex = 42, Text = "", Font = F.bold, TextSize = 20, TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.new(1, 0, 0, 28) })
local mGrade = text({ Parent = box, ZIndex = 42, Text = "", Font = F.bold, TextSize = 52, TextColor3 = C.accent, TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.new(1, 0, 0, 70), Position = UDim2.fromOffset(0, 36) })
local mDesc = text({ Parent = box, ZIndex = 42, Text = "", TextSize = 14, TextColor3 = C.muted, TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.new(1, 0, 0, 44), Position = UDim2.fromOffset(0, 112) })
local retryBtn = button({ Parent = box, ZIndex = 42, Text = "확인", TextSize = 16, AnchorPoint = Vector2.new(0, 1), Size = UDim2.new(1, 0, 0, 44), Position = UDim2.fromScale(0, 1) })

-------------------------------------------------------------------
-- 부정행위 목록
-------------------------------------------------------------------
local cheats = {}
local selected = 1
local refreshUpShop -- 아래에서 정의

local function meter(parent, y, name, pct, color)
	text({ Parent = parent, Text = name, TextSize = 11, TextColor3 = C.muted, Size = UDim2.new(0, 60, 0, 12), Position = UDim2.fromOffset(0, y) })
	text({ Parent = parent, Text = pct .. "%", Font = F.mid, TextSize = 11, TextColor3 = C.text, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(0, 40, 0, 12), Position = UDim2.new(1, -40, 0, y) })
	local bg = new("Frame", { Parent = parent, BackgroundColor3 = C.sub, Size = UDim2.new(1, -120, 0, 4), Position = UDim2.fromOffset(64, y + 4) }, { corner(2) })
	new("Frame", { Parent = bg, BackgroundColor3 = color, Size = UDim2.new(pct / 100, 0, 1, 0) }, { corner(2) })
end

local function renderCheats()
	for _, ch in ipairs(list:GetChildren()) do
		if ch:IsA("GuiObject") then
			ch:Destroy()
		end
	end
	for i, c in ipairs(cheats) do
		local on = i == selected
		local item = new("TextButton", { Parent = list, LayoutOrder = i, Text = "", AutoButtonColor = false, BackgroundColor3 = on and Color3.fromRGB(240, 243, 251) or C.surface, Size = UDim2.new(1, -4, 0, 76) }, { corner(8), pad(12, 10) })
		local st = stroke(on and C.accent or C.line, on and 2 or 1)
		st.Parent = item
		text({ Parent = item, Text = c.name, Font = F.bold, TextSize = 14, Size = UDim2.new(1, -90, 0, 18), TextTruncate = Enum.TextTruncate.AtEnd })
		text({ Parent = item, Text = c.type, TextSize = 11, TextColor3 = c.pro and Color3.fromRGB(130, 70, 220) or C.muted, TextXAlignment = Enum.TextXAlignment.Right, Size = UDim2.new(0, 90, 0, 18), Position = UDim2.new(1, -90, 0, 0) })
		meter(item, 26, "성공률", c.success, C.ok)
		meter(item, 42, "적발 확률", c.risk, C.danger)
		item.MouseButton1Click:Connect(function()
			selected = i
			renderCheats()
		end)
	end
	curLabel.Text = "선택: " .. (cheats[selected] and cheats[selected].name or "-")
end

local function addCheat(name)
	name = string.gsub(name or "", "^%s+", "")
	name = string.gsub(name, "%s+$", "")
	name = Shared.clip(name, 20)
	if name == "" then
		return
	end
	for i, c in ipairs(cheats) do
		if c.name == name then
			selected = i
			renderCheats()
			return
		end
	end
	table.insert(cheats, 1, Shared.makeCheat(name, owned[name], gearLv[name]))
	selected = 1
	renderCheats()
end

for _, n in ipairs({ "옆자리 친구", "손바닥 필기", "스마트워치" }) do
	addCheat(n)
end

refreshUpShop = function()
	local c = cheats[selected]
	for id, r in pairs(upRows) do
		local lv
		if id == "gear" then
			r.title.Text = "장비 강화: " .. (c and c.name or "-")
			lv = c and (gearLv[c.name] or 0) or 0
		else
			lv = perkLv[id] or 0
		end
		if lv >= r.def.max then
			r.info.Text = "Lv " .. lv .. " / " .. r.def.max .. "  (최대)"
			r.button.Text = "최대"
			r.button.BackgroundColor3 = Color3.fromRGB(150, 155, 165)
		else
			r.info.Text = "Lv " .. lv .. " / " .. r.def.max
			r.button.Text = Shared.doubled(r.def.base, lv) .. "원"
			r.button.BackgroundColor3 = UP_ACCENT
		end
	end
end
for id, r in pairs(upRows) do
	r.button.MouseButton1Click:Connect(function()
		local c = cheats[selected]
		remote:FireServer("Upgrade", id, c and c.name or "")
	end)
end

customBtn.MouseButton1Click:Connect(function()
	local c = cheats[selected]
	if c then
		if owned[c.name] then
			toast("이미 정품을 가지고 있어요.")
		else
			remote:FireServer("BuyPro", c.name)
		end
	end
end)

-------------------------------------------------------------------
-- 한글 입력기 (두벌식)
-- Roblox 입력칸은 한글 조합(IME)이 안 되는 경우가 있어서
-- 누른 키를 직접 받아서 한글로 조합합니다.
-------------------------------------------------------------------
local CHO = { "ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ" }
local JUNG = { "ㅏ", "ㅐ", "ㅑ", "ㅒ", "ㅓ", "ㅔ", "ㅕ", "ㅖ", "ㅗ", "ㅘ", "ㅙ", "ㅚ", "ㅛ", "ㅜ", "ㅝ", "ㅞ", "ㅟ", "ㅠ", "ㅡ", "ㅢ", "ㅣ" }
local JONG = { "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ" }
local CHO_I, JUNG_I, JONG_I = {}, {}, {}
for i, v in ipairs(CHO) do
	CHO_I[v] = i - 1
end
for i, v in ipairs(JUNG) do
	JUNG_I[v] = i - 1
end
for i, v in ipairs(JONG) do
	JONG_I[v] = i
end
local VCOMB = { ["ㅗㅏ"] = "ㅘ", ["ㅗㅐ"] = "ㅙ", ["ㅗㅣ"] = "ㅚ", ["ㅜㅓ"] = "ㅝ", ["ㅜㅔ"] = "ㅞ", ["ㅜㅣ"] = "ㅟ", ["ㅡㅣ"] = "ㅢ" }
local JCOMB = { ["ㄱㅅ"] = "ㄳ", ["ㄴㅈ"] = "ㄵ", ["ㄴㅎ"] = "ㄶ", ["ㄹㄱ"] = "ㄺ", ["ㄹㅁ"] = "ㄻ", ["ㄹㅂ"] = "ㄼ", ["ㄹㅅ"] = "ㄽ", ["ㄹㅌ"] = "ㄾ", ["ㄹㅍ"] = "ㄿ", ["ㄹㅎ"] = "ㅀ", ["ㅂㅅ"] = "ㅄ" }
local JSPLIT = {}
for k, v in pairs(JCOMB) do
	JSPLIT[v] = { string.sub(k, 1, 3), string.sub(k, 4, 6) } -- 자모는 3바이트
end
local KEYMAP = {
	Q = "ㅂ", W = "ㅈ", E = "ㄷ", R = "ㄱ", T = "ㅅ", Y = "ㅛ", U = "ㅕ", I = "ㅑ", O = "ㅐ", P = "ㅔ",
	A = "ㅁ", S = "ㄴ", D = "ㅇ", F = "ㄹ", G = "ㅎ", H = "ㅗ", J = "ㅓ", K = "ㅏ", L = "ㅣ",
	Z = "ㅋ", X = "ㅌ", C = "ㅊ", V = "ㅍ", B = "ㅠ", N = "ㅜ", M = "ㅡ",
}
local SHIFTMAP = { Q = "ㅃ", W = "ㅉ", E = "ㄸ", R = "ㄲ", T = "ㅆ", O = "ㅒ", P = "ㅖ" }
local DIGITS = { Zero = "0", One = "1", Two = "2", Three = "3", Four = "4", Five = "5", Six = "6", Seven = "7", Eight = "8", Nine = "9" }

-- 입력한 자모/글자 목록 → 완성된 문자열
local function compose(units)
	local out = {}
	local cho, jung, jong
	local function flush()
		if cho and jung then
			out[#out + 1] = utf8.char(0xAC00 + (CHO_I[cho] * 21 + JUNG_I[jung]) * 28 + (jong and JONG_I[jong] or 0))
		elseif cho then
			out[#out + 1] = cho
		elseif jung then
			out[#out + 1] = jung
		end
		cho, jung, jong = nil, nil, nil
	end
	for _, u in ipairs(units) do
		if CHO_I[u] then -- 자음
			if cho and jung then
				if not jong then
					if JONG_I[u] then
						jong = u
					else
						flush()
						cho = u
					end
				elseif JCOMB[jong .. u] then
					jong = JCOMB[jong .. u]
				else
					flush()
					cho = u
				end
			else
				flush()
				cho = u
			end
		elseif JUNG_I[u] then -- 모음
			if cho and jung and jong then
				local nextCho
				if JSPLIT[jong] then
					jong, nextCho = JSPLIT[jong][1], JSPLIT[jong][2]
				else
					jong, nextCho = nil, jong
				end
				flush()
				cho, jung = nextCho, u
			elseif jung then
				if VCOMB[jung .. u] then
					jung = VCOMB[jung .. u]
				else
					flush()
					jung = u
				end
			else
				jung = u
			end
		else -- 영어, 숫자, 띄어쓰기
			flush()
			out[#out + 1] = u
		end
	end
	flush()
	return table.concat(out)
end

local units = {}
local hangulMode = true
local focused = false
local caretOn = true

local function refreshField()
	local str = compose(units)
	if str == "" and not focused then
		fieldText.Text = "예) 스마트워치, 지우개"
		fieldText.TextColor3 = C.muted
	else
		fieldText.Text = str .. ((focused and caretOn) and "|" or "")
		fieldText.TextColor3 = C.text
	end
	field.UIStroke.Color = focused and C.accent or C.line
	modeBtn.Text = hangulMode and "한" or "A"
end

local function submitInput()
	if useCustomField then
		local t = compose(units)
		units = {}
		refreshField()
		addCheat(t)
	else
		task.defer(function()
			local t = input.Text
			input.Text = ""
			addCheat(t)
		end)
	end
end

local function setFocus(on)
	if focused == on then
		return
	end
	focused = on
	if on then
		ContextActionService:BindActionAtPriority("SuneungTyping", function(_, state, obj)
			if state ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Sink
			end
			local key = obj.KeyCode
			local name = key.Name
			local shift = UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) or UserInputService:IsKeyDown(Enum.KeyCode.RightShift)
			if key == Enum.KeyCode.Return or key == Enum.KeyCode.KeypadEnter then
				submitInput()
			elseif key == Enum.KeyCode.Escape then
				setFocus(false)
			elseif key == Enum.KeyCode.Backspace then
				table.remove(units)
			elseif key == Enum.KeyCode.Space then
				table.insert(units, " ")
			elseif key == Enum.KeyCode.RightAlt or key == Enum.KeyCode.Tab then
				hangulMode = not hangulMode
			elseif DIGITS[name] then
				table.insert(units, DIGITS[name])
			elseif KEYMAP[name] then
				if hangulMode then
					table.insert(units, (shift and SHIFTMAP[name]) or KEYMAP[name])
				else
					table.insert(units, shift and name or string.lower(name))
				end
			end
			-- 20자 넘으면 마지막 입력 취소
			if utf8.len(compose(units)) > 20 then
				table.remove(units)
			end
			refreshField()
			return Enum.ContextActionResult.Sink
		end, false, Enum.ContextActionPriority.High.Value + 100,
		Enum.KeyCode.A, Enum.KeyCode.B, Enum.KeyCode.C, Enum.KeyCode.D, Enum.KeyCode.E, Enum.KeyCode.F, Enum.KeyCode.G,
		Enum.KeyCode.H, Enum.KeyCode.I, Enum.KeyCode.J, Enum.KeyCode.K, Enum.KeyCode.L, Enum.KeyCode.M, Enum.KeyCode.N,
		Enum.KeyCode.O, Enum.KeyCode.P, Enum.KeyCode.Q, Enum.KeyCode.R, Enum.KeyCode.S, Enum.KeyCode.T, Enum.KeyCode.U,
		Enum.KeyCode.V, Enum.KeyCode.W, Enum.KeyCode.X, Enum.KeyCode.Y, Enum.KeyCode.Z,
		Enum.KeyCode.Zero, Enum.KeyCode.One, Enum.KeyCode.Two, Enum.KeyCode.Three, Enum.KeyCode.Four,
		Enum.KeyCode.Five, Enum.KeyCode.Six, Enum.KeyCode.Seven, Enum.KeyCode.Eight, Enum.KeyCode.Nine,
		Enum.KeyCode.Space, Enum.KeyCode.Backspace, Enum.KeyCode.Return, Enum.KeyCode.KeypadEnter,
		Enum.KeyCode.Escape, Enum.KeyCode.RightAlt, Enum.KeyCode.Tab)
	else
		ContextActionService:UnbindAction("SuneungTyping")
	end
	refreshField()
end

field.MouseButton1Click:Connect(function()
	setFocus(true)
end)
modeBtn.MouseButton1Click:Connect(function()
	hangulMode = not hangulMode
	setFocus(true)
	refreshField()
end)
-- 입력창 밖을 클릭하면 입력 끝
UserInputService.InputBegan:Connect(function(obj)
	if focused and obj.UserInputType == Enum.UserInputType.MouseButton1 then
		local p = obj.Position
		local function inside(g)
			local a, s = g.AbsolutePosition, g.AbsoluteSize
			return p.X >= a.X and p.X <= a.X + s.X and p.Y >= a.Y and p.Y <= a.Y + s.Y
		end
		if not (inside(field) or inside(modeBtn) or inside(addBtn)) then
			setFocus(false)
		end
	end
end)
task.spawn(function()
	while true do
		task.wait(0.5)
		caretOn = not caretOn
		if focused then
			refreshField()
		end
	end
end)
refreshField()

addBtn.MouseButton1Click:Connect(submitInput)
input.FocusLost:Connect(function(enter)
	if enter then
		submitInput()
	end
end)

-------------------------------------------------------------------
-- 시험 진행
-------------------------------------------------------------------
local logs = {}
local timeLeft, suspicion, qNum, qTotal = Shared.TIME_LIMIT, 0, 0, Shared.TOTAL_Q
local cheatingUntil = nil
local cheatDur = Shared.CHEAT_TIME
local inExam = false

local function updateStatus()
	if not inExam then
		status.Text = "대기 중"
		return
	end
	status.Text = string.format("문제 %d / %d     남은 시간 %d:%02d     의심도 %d%%", qNum, qTotal, math.floor(timeLeft / 60), timeLeft % 60, suspicion)
end

local function setExamMode(on)
	inExam = on
	startBtn.Visible = not on
	cheatBtn.Visible = on
	leaveBtn.Visible = on
	leaveBtn.Text = "몰래 나가기"
	paper.Visible = on
	progBg.Visible = false
	hintLabel.Text = ""
	updateStatus()
end

nukeBtn.MouseButton1Click:Connect(function()
	remote:FireServer("Nuke")
end)
floodBtn.MouseButton1Click:Connect(function()
	remote:FireServer("Flood")
end)
poopBtn.MouseButton1Click:Connect(function()
	remote:FireServer("Poop")
end)

startBtn.MouseButton1Click:Connect(function()
	local c = cheats[selected]
	if c then
		remote:FireServer("Start", c.name)
	end
end)

local away = false
leaveBtn.MouseButton1Click:Connect(function()
	remote:FireServer(away and "Return" or "Leave")
end)

local function renderBag(inv)
	for _, ch in ipairs(bagList:GetChildren()) do
		if ch:IsA("GuiObject") then
			ch:Destroy()
		end
	end
	local any = false
	local all = {}
	for _, it in ipairs(Shared.SPECIAL) do
		table.insert(all, it)
	end
	for _, it in ipairs(Shared.SHOP) do
		table.insert(all, it)
	end
	for i, it in ipairs(all) do
		local n = inv[it.id]
		if n and n > 0 then
			any = true
			local row = new("Frame", { Parent = bagList, LayoutOrder = i, BackgroundColor3 = C.sub, Size = UDim2.new(1, -4, 0, 32) }, { corner(6) })
			text({ Parent = row, Text = it.name .. "  x" .. n, Font = F.mid, TextSize = 13, Size = UDim2.new(1, -70, 1, 0), Position = UDim2.fromOffset(10, 0) })
			local eat = button({ Parent = row, Text = it.special and "사용" or "먹기", BackgroundColor3 = it.special and Color3.fromRGB(200, 140, 0) or nil, TextSize = 12, AnchorPoint = Vector2.new(1, 0.5), Size = UDim2.fromOffset(52, 24), Position = UDim2.new(1, -4, 0.5, 0) })
			eat.MouseButton1Click:Connect(function()
				remote:FireServer("Eat", it.id)
			end)
		end
	end
	bagEmpty.Visible = not any
end
renderBag({})

local function showMoney(v)
	moneyLabel.Text = v .. "원"
	shopMoney.Text = "가진 돈 " .. v .. "원"
	proMoney.Text = "가진 돈 " .. v .. "원"
	upMoney.Text = "가진 돈 " .. v .. "원"
end
task.spawn(function()
	local ls = player:WaitForChild("leaderstats")
	local m = ls:WaitForChild("돈")
	showMoney(m.Value)
	m.Changed:Connect(showMoney)
end)

cheatBtn.MouseButton1Click:Connect(function()
	local c = cheats[selected]
	if c and not cheatingUntil then
		remote:FireServer("Cheat", c.name)
	end
end)

submitBtn.MouseButton1Click:Connect(function()
	if not picked then
		paperMsg.Text = "답을 선택하세요."
		return
	end
	paperMsg.Text = ""
	remote:FireServer("Answer", picked)
end)

retryBtn.MouseButton1Click:Connect(function()
	modal.Visible = false
	setExamMode(false)
end)

RunService.RenderStepped:Connect(function()
	if cheatingUntil then
		local remain = cheatingUntil - os.clock()
		progFill.Size = UDim2.new(math.clamp(1 - remain / cheatDur, 0, 1), 0, 1, 0)
	end
end)

local function showDomain(who)
	domainWho.Text = who .. " 적발"
	domainImg.Visible = Shared.DOMAIN_IMAGE ~= "rbxassetid://0"
	domainImg.ImageTransparency = 1
	domainText.TextTransparency = 1
	domainText.TextStrokeTransparency = 1
	domainImg.Size = UDim2.fromScale(0.55, 0.6)
	domain.Visible = true
	local fast = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	TweenService:Create(domainImg, fast, { ImageTransparency = 0, Size = UDim2.fromScale(0.4, 0.45) }):Play()
	TweenService:Create(domainText, fast, { TextTransparency = 0, TextStrokeTransparency = 0 }):Play()
	local base = UDim2.fromScale(0.5, 0.42)
	local t0 = os.clock()
	local conn
	conn = RunService.RenderStepped:Connect(function()
		if os.clock() - t0 > 1.5 then
			conn:Disconnect()
			domainImg.Position = base
			return
		end
		domainImg.Position = base + UDim2.fromOffset(math.random(-3, 3), math.random(-3, 3))
	end)
	task.delay(1.5, function()
		local slow = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		TweenService:Create(domainImg, slow, { ImageTransparency = 1, Size = UDim2.fromScale(0.3, 0.32) }):Play()
		TweenService:Create(domainText, slow, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
		task.wait(0.5)
		domain.Visible = false
	end)
end

-------------------------------------------------------------------
-- 1등급 엔딩: 서울대 합격 → "인줄 알았는데......." → 회사 면접
-------------------------------------------------------------------
local INTERVIEW = {
	{ q = "자기소개 해보세요.", a = {
		{ "열정 하나는 자신 있습니다!", 1 },
		{ "수능 1등급 받았습니다.", 1 },
		{ "……(긴장해서 아무 말도 못 함)", 0 },
	} },
	{ q = "수능 1등급의 비결은 무엇인가요?", a = {
		{ "꾸준한 노력입니다.", 1 },
		{ "AI 안경이요.", "confess" },
		{ "운이 좋았습니다.", 0 },
	} },
	{ q = "우리 회사에 지원한 이유는?", a = {
		{ "세상을 바꾸는 기술을 만들고 싶어서요.", 1 },
		{ "매점보다 월급이 많을 것 같아서요.", 0 },
		{ "엄마가 가래요.", 0 },
	} },
	{ q = "마지막으로 하고 싶은 말은?", a = {
		{ "뽑아주시면 열심히 하겠습니다!", 1 },
		{ "저 사실 저격수 100명도 피했습니다.", 0 },
		{ "점심 메뉴가 뭔가요?", 0 },
	} },
}

local endingLayer = new("Frame", { Parent = gui, BackgroundColor3 = Color3.new(0, 0, 0), Size = UDim2.fromScale(1, 1), ZIndex = 150, Visible = false })

local function clearEnding()
	for _, ch in ipairs(endingLayer:GetChildren()) do
		ch:Destroy()
	end
end
local function eText(str, size, color, posY, font, zi)
	return text({ Parent = endingLayer, ZIndex = zi or 160, Text = str, Font = font or F.bold, TextScaled = true, TextColor3 = color or Color3.new(1, 1, 1), TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.8, size), Position = UDim2.fromScale(0.5, posY) })
end
local function eBox(color, size, pos, zi, r)
	local f = new("Frame", { Parent = endingLayer, BackgroundColor3 = color, BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 1), Size = size, Position = pos, ZIndex = zi or 152 })
	if r then
		corner(r).Parent = f
	end
	return f
end
local function fadeIn(o, t)
	if o:IsA("TextLabel") or o:IsA("TextButton") then
		o.TextTransparency = 1
		TweenService:Create(o, TweenInfo.new(t or 0.6), { TextTransparency = 0 }):Play()
	end
end

-- 장면 1: 서울대 합격
local function sceneUniversity()
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.fromRGB(140, 200, 245)
	-- 잔디와 정문 (단순한 도형으로 그린 학교 정문)
	eBox(Color3.fromRGB(110, 170, 90), UDim2.fromScale(1, 0.25), UDim2.fromScale(0.5, 1), 151)
	eBox(Color3.fromRGB(235, 235, 230), UDim2.fromScale(0.05, 0.42), UDim2.fromScale(0.33, 0.78), 152)
	eBox(Color3.fromRGB(235, 235, 230), UDim2.fromScale(0.05, 0.42), UDim2.fromScale(0.67, 0.78), 152)
	local beam = eBox(Color3.fromRGB(70, 90, 140), UDim2.fromScale(0.42, 0.07), UDim2.fromScale(0.5, 0.42), 153, 6)
	text({ Parent = beam, ZIndex = 154, Text = "서울대학교", Font = F.bold, TextScaled = true, TextColor3 = Color3.new(1, 1, 1), TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.fromScale(1, 0.8), Position = UDim2.fromScale(0, 0.1) })
	local t1 = eText("합격을 축하합니다!", 0.1, Color3.fromRGB(30, 40, 80), 0.16, F.bold, 160)
	local t2 = eText("수능 1등급. 부모님이 우신다. 동네에 현수막이 걸렸다.", 0.04, Color3.fromRGB(40, 50, 90), 0.27, F.mid, 160)
	fadeIn(t1)
	fadeIn(t2, 1)
	-- 꽃가루
	local colors = { Color3.fromRGB(255, 90, 90), Color3.fromRGB(255, 210, 60), Color3.fromRGB(90, 200, 255), Color3.fromRGB(120, 230, 120), Color3.fromRGB(230, 120, 255) }
	for _ = 1, 70 do
		local x = math.random()
		local c = new("Frame", { Parent = endingLayer, BackgroundColor3 = colors[math.random(1, #colors)], BorderSizePixel = 0, Size = UDim2.fromOffset(math.random(6, 12), math.random(10, 18)), Position = UDim2.new(x, 0, -0.05, 0), Rotation = math.random(0, 360), ZIndex = 170 })
		TweenService:Create(c, TweenInfo.new(2.5 + math.random() * 2.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, math.random() * 1.5), {
			Position = UDim2.new(x + (math.random() - 0.5) * 0.2, 0, 1.05, 0),
			Rotation = math.random(-720, 720),
		}):Play()
	end
	task.wait(5.5)
end

-------------------------------------------------------------------
-- 엔딩 시험 문제 은행 (각 50문제)
-- 한 줄 = "문제|정답|오답|오답|오답"  (보기 순서는 실행할 때 섞음)
-------------------------------------------------------------------
local SNU_ROWS = {
	"물의 끓는점(1기압)은?|100°C|90°C|120°C|0°C",
	"지구에서 가장 높은 산은?|에베레스트|한라산|백두산|후지산",
	"훈민정음이 반포된 해는?|1446년|1392년|1592년|1910년",
	"원주율 π의 근삿값은?|3.14|2.71|1.41|1.73",
	"DNA 이중나선 구조가 발표된 해는?|1953년|1905년|1969년|1876년",
	"산소의 원소기호는?|O|Os|Ox|S",
	"금의 원소기호는?|Au|Ag|Go|Gd",
	"빛의 삼원색이 아닌 것은?|노랑|빨강|초록|파랑",
	"『삼국사기』를 쓴 사람은?|김부식|일연|정약용|이황",
	"거북선과 관련된 인물은?|이순신|강감찬|을지문덕|권율",
	"태양계에서 가장 작은 행성은?|수성|화성|금성|지구",
	"세계에서 가장 넓은 나라는?|러시아|캐나다|중국|미국",
	"만유인력의 법칙을 발표한 사람은?|뉴턴|아인슈타인|갈릴레이|다윈",
	"상대성이론을 발표한 사람은?|아인슈타인|뉴턴|파스칼|보어",
	"광합성이 일어나는 세포 소기관은?|엽록체|미토콘드리아|핵|리보솜",
	"성인의 뼈는 대략 몇 개?|206개|106개|306개|56개",
	"1 km는 몇 m?|1000 m|100 m|10000 m|10 m",
	"정육면체의 면은 몇 개?|6개|8개|4개|12개",
	"조선을 세운 왕은?|태조 이성계|세종|왕건|주몽",
	"경국대전을 완성해 반포한 왕은?|성종|세종|태종|영조",
}

local ARMY_ROWS = {
	"군대에서 가장 중요한 것은?|전우애|선임 눈치|휴가|짬밥",
	"'다나까' 말투로 바른 것은?|알겠습니다|알겠어요|알았지?|ㅇㅋ",
	"기상 시간은?|06:00|09:00|12:00|자유",
	"상관이 부를 때 대답은?|\"네, 일병 OOO!\"|\"왜요?\"|\"잠깐만요\"|못 들은 척",
	"총기 손질은 언제?|매일 꼼꼼히|생각날 때|전역 전날|안 한다",
	"경계 근무 중 졸리면?|정신 차리고 근무|잔다|폰을 본다|노래를 부른다",
	"'전역'의 뜻은?|군 복무를 마침|입대|휴가|훈련",
	"행군할 때 가장 중요한 것은?|발 관리|간식|셀카|빠른 포기",
	"군대 식사를 부르는 말은?|짬밥|급식|코스요리|뷔페",
	"PX에서 파는 것은?|간식과 생활용품|자동차|집|비행기",
	"침상 정리는?|각 잡아서|대충|안 한다|남이 해 줌",
	"훈련 중 비가 오면?|그대로 훈련|훈련 취소|집에 감|우산 펴고 누움",
	"'이병' 다음 계급은?|일병|병장|상병|하사",
	"'상병' 다음 계급은?|병장|일병|중사|소위",
	"군인의 기본자세는?|차렷|누워|엎드려 자|대충 서",
	"위장 크림은 어디에 바르나?|얼굴|밥|총|신발",
	"초소에서 암구호를 모르면?|큰일 난다|괜찮다|노래로 대신|웃으면 통과",
	"휴가 복귀 시간을 어기면?|징계를 받는다|칭찬받는다|휴가 연장|아무 일 없다",
	"군화 끈은?|단단히 묶는다|풀어 둔다|잘라 버린다|친구가 묶어 줌",
	"점호 때 할 일은?|인원 확인에 응답|숨기|자기|도망",
	"유격 훈련의 구호는?|유격!|할렐루야!|료이키 텐카이!|1등급!",
	"수류탄 훈련에서 핀을 뽑은 뒤?|던진다|들고 있는다|주머니에 넣는다|친구에게 준다",
	"사격 훈련 전 확인할 것은?|안전 수칙|점심 메뉴|오늘의 운세|게임 업데이트",
	"군인이 받는 월급의 이름은?|봉급|용돈|세뱃돈|상금",
	"야간 행군에 필요한 것은?|체력과 인내|AI 안경|핵폭탄|모바일 게임",
	"생활관 청소 당번은?|정해진 순서대로|선임 마음대로|아무도 안 함|로봇",
	"전투복을 입는 이유는?|위장과 활동성|패션|잠옷|파티",
	"군대에서 편지를 쓰는 대상은?|가족과 친구|감독관|저격수|매점 아주머니",
	"혹한기 훈련 때 입는 것은?|방한복|반팔|수영복|정장",
	"군 복무의 의미는?|나라를 지킨다|휴가 모으기|살 빼기|친구 사귀기만",
	"화생방 훈련에서 쓰는 것은?|방독면|선글라스|마스크팩|AI 안경",
	"'충성!'은 언제 외치나?|경례할 때|밥 먹을 때|잘 때|화장실에서",
	"탄약은 어디에 보관하나?|탄약고|사물함|베개 밑|매점",
	"신병이 가장 먼저 배우는 것은?|제식훈련|요리|춤|운전",
	"부대 정문을 지키는 근무는?|위병소 근무|매점 근무|PC방 알바|택배",
	"'짬이 찬다'는 뜻은?|경력이 쌓인다|배가 부르다|짐이 많다|비가 온다",
	"훈련 중 다친 동기를 보면?|도와준다|모른 척|사진 찍기|웃기",
	"장비를 잃어버리면?|즉시 보고한다|숨긴다|남 탓|전역까지 모른 척",
	"전역 날 하는 말은?|\"그동안 감사했습니다\"|\"재입대하겠습니다\"|아무 말 없이 도망|\"짬밥 맛있었다\"만",
	"군대에서 줄 서는 순서는?|지시에 따라|아무렇게나|키 큰 순|이름 가나다순",
	"불침번이 하는 일은?|밤에 순찰|밤새 게임|요리|운동만",
	"병사 체력검정 종목이 아닌 것은?|줄넘기|팔굽혀펴기|윗몸일으키기|3km 달리기",
	"비상 사이렌이 울리면?|신속히 전투 준비|더 잔다|매점에 감|모른 척",
	"행정반은 무엇을 하는 곳?|부대 행정 업무|노래방|식당|헬스장",
	"군인이 지켜야 할 것은?|군기와 규율|유행|SNS 팔로워|게임 랭킹",
	"동상을 예방하려면?|발을 건조하게|맨발로 다니기|눈 먹기|얼음 목욕",
	"훈련소 수료식에 오는 사람은?|가족|저격수|감독관|뉴비 차",
	"군대에서 가장 기다려지는 날은?|휴가 날|훈련 날|청소 날|점호 날",
	"취침 나팔이 울리면?|잠자리에 든다|노래방 간다|PX 간다|훈련 시작",
	"다시 입대하겠습니까?|한 번이면 충분합니다|당장 갑니다|평생 있겠습니다|핵폭탄 쏘겠습니다",
}

local LIFE_ROWS = {
	"월급날 가장 먼저 할 일은?|저축|매점에서 다 쓰기|부정행위 장비 구매|핵폭탄 발사",
	"행복의 조건은?|건강|1등급|AI 안경|저격수 100명",
	"부정행위는?|하면 안 된다|안 들키면 된다|AI 안경이면 괜찮다|모르겠다",
	"친구가 힘들어하면?|이야기를 들어준다|무시|놀린다|똥을 싼다",
	"첫 출근 날 할 일은?|일찍 도착해서 인사|지각|결근|퇴근부터",
	"돈을 빌렸다면?|약속한 날에 갚는다|잠수|더 빌린다|핵폭탄",
	"건강을 지키는 방법은?|운동과 균형 잡힌 식사|컵라면만 먹기|밤새기|에너지드링크 10캔",
	"실패했을 때는?|배우고 다시 도전|포기|남 탓|가루 되기",
	"부모님께 연락은?|자주 한다|1년에 한 번|안 한다|용돈 필요할 때만",
	"약속에 늦을 것 같으면?|미리 연락하고 사과|모른 척|화낸다|안 간다",
	"좋은 습관은?|일찍 자고 일찍 일어나기|새벽 4시 취침|하루 한 끼|매일 홍수",
	"스트레스 해소법은?|산책과 휴식|핵폭탄 발사|소리 지르기|남에게 화풀이",
	"축의금 봉투에 쓰는 것은?|내 이름|욕|성적표|암구호",
	"이사할 때 필요한 것은?|짐 정리와 계획|차 50대|저격수|핵 벙커",
	"집을 사려면?|저축과 계획|복권 한 장|부정행위|1등급 상품권",
	"회사에서 실수했다면?|바로 보고하고 해결|숨긴다|퇴사|남 탓",
	"운전할 때 지켜야 할 것은?|교통 법규|최고 속도|베이컨 차 따라가기|사람 치기",
	"세금을 내는 이유는?|나라 살림에 필요해서|재미로|벌금이라서|안 내도 된다",
	"은퇴 후 하고 싶은 것은?|취미와 여행|수능 재도전|저격수 취직|아무것도",
	"인생에서 가장 중요한 시험은?|정직함|수능|운전면허|할렐루야 시험",
	"자기계발 방법은?|꾸준한 독서와 공부|AI 안경 구매|잠|게임만",
	"이웃을 만나면?|반갑게 인사|못 본 척|째려보기|똥 놓고 가기",
	"쓰레기는?|분리수거|길에 버림|바다에 버림|교실에 둠",
	"다이어트 비법은?|꾸준한 운동과 식단|굶기|매점 털기|핵폭탄",
	"첫 월급으로 부모님께 드릴 것은?|감사의 선물|청구서|성적표|똥",
	"면접에서 가장 중요한 것은?|진솔함|AI 안경|거짓말|지각",
	"아이가 생기면?|사랑으로 키운다|부정행위 교육|방치|저격수로 키운다",
	"병원에 가야 할 때는?|아플 때 바로|죽기 직전|절대 안 감|홍수 날 때만",
	"보험은 왜 드나?|사고에 대비하려고|재미로|강제라서|모른다",
	"신용카드 사용법은?|갚을 만큼만|한도 끝까지|남의 카드로|안 갚기",
	"휴가 계획은?|미리 세운다|당일 결정|휴가 안 감|영원히 휴가",
	"동료가 칭찬받으면?|함께 축하한다|질투|방해|가루로 만든다",
	"새해 목표는?|작고 구체적으로|세계 정복|핵폭탄 10개|아무것도",
	"노후 준비는?|일찍부터 조금씩|나중에|안 함|1등급 상품권으로",
	"아침밥은?|챙겨 먹는다|에너지드링크로|굶는다|저녁에 먹는다",
	"비 오는 날 필요한 것은?|우산|선글라스|핵 벙커|베이컨",
	"다툰 뒤에는?|대화로 화해|1년 침묵|가출|홍수 버튼",
	"거짓말을 했다면?|솔직히 사과|더 큰 거짓말|증거 인멸|도망",
	"반려동물을 키우려면?|끝까지 책임진다|귀찮으면 버린다|매점에 맡긴다|저격수에게 맡긴다",
	"가장 큰 재산은?|사람과 건강|차 50대|돈|AI 안경",
	"시험에 떨어졌다면?|다시 준비|부정행위 준비|세상 탓|포기",
	"할머니 생신에는?|찾아뵙고 축하|연락 안 함|잊어버림|핵폭탄 선물",
	"길을 잃으면?|지도 확인이나 길 묻기|무작정 직진|울기|도로 한가운데서 기다리기",
	"은행 비밀번호는?|나만 안다|모두에게 공유|1234|SNS에 올림",
	"중고 거래할 때는?|물건 확인 후 거래|먼저 송금|모르는 링크 클릭|아무나 믿기",
	"일과 휴식의 균형은?|둘 다 중요|일만|휴식만|핵폭탄",
	"친구의 비밀은?|지켜 준다|소문낸다|팔아먹는다|칠판에 쓴다",
	"어른이 된다는 것은?|책임을 지는 것|수능이 끝나는 것|잔소리 듣는 것|차 50대 모으기",
	"인생의 정답은?|스스로 찾아가는 것|AI 안경|1번|할렐루야",
	"지금까지의 인생 점수는?|스스로 만족하면 만점|0점|1등급|가루",
}

local HEAVEN_ROWS = {
	"살면서 부정행위를 한 적이 있나요?|있습니다|없습니다|기억이 안 납니다|AI 안경이 했습니다",
	"천국에 가져갈 수 있는 것은?|착한 마음|돈|스마트워치|1등급 상품권",
	"날개를 받으면 할 일은?|남을 돕기|커닝|똥누기|핵폭탄 발사",
	"천사에게 인사할 때는?|공손하게|반말로|무시|료이키 텐카이",
	"천국의 화폐는?|착한 일|원화|1등급 상품권|베이컨",
	"천국 문지기에게 뇌물을?|주지 않는다|AI 안경을 준다|매점 상품권|핵폭탄",
	"구름 위에서 하면 안 되는 것은?|부정행위|노래|산책|휴식",
	"천국에서 다시 만나고 싶은 사람은?|소중한 가족|감독관|저격수|뉴비 차",
	"천국 입구에 줄을 설 때는?|차례를 지킨다|새치기|날아서 넘기|핵폭탄",
	"살면서 가장 잘한 일은?|남을 도운 일|1등급 받은 일|저격수 피한 일|똥 싼 일",
	"천사 머리 위에 있는 것은?|빛나는 고리|헬멧|베이컨|AI 안경",
	"천국의 날씨는?|늘 맑음|홍수|핵폭탄|저격 주의보",
	"천국 시험에서 커닝하면?|바로 탈락|1등급|괜찮음|칭찬",
	"하늘에서 내려다본 지구는?|아름답다|시험장이다|베이컨 같다|핵 구덩이",
	"천국에서 입는 옷은?|하얀 옷|군복|교복|전투복",
	"후회되는 일이 있다면?|진심으로 반성|남 탓|없다고 우김|기억 삭제",
	"천국의 음악 소리는?|하프|사이렌|총소리|차 경적",
	"천국에서 먹는 음식은?|마음의 양식|컵라면|짬밥|베이컨 차",
	"천국의 문은 어떻게 생겼나?|진주처럼 빛남|녹슨 철문|교실 문|벙커 문",
	"누군가를 미워했던 적이 있다면?|용서를 구한다|더 미워한다|모른 척|복수",
	"천국에서 하는 일은?|평화롭게 쉬기|야근|시험 감독|저격",
	"천국 신분증은?|착한 마음|주민등록증|수험표|군번줄",
	"천사가 시험지를 나눠 주면?|정직하게 푼다|AI 안경 착용|옆 천사 커닝|도망",
	"새치기하는 사람에게는?|정중히 말한다|밀친다|핵폭탄|저격",
	"지상에 남긴 것은?|좋은 추억|빚|똥|핵 구덩이",
	"문지기가 이름을 물으면?|정직하게 대답|가명|\"1등급입니다\"|\"뉴비입니다\"",
	"천국의 시간은?|영원|2분|50분|수능 시간",
	"천국 우체국에서 편지를 보낼 대상은?|지상의 가족|감독관|저격수 100명|매점",
	"천국에서 다툼이 생기면?|대화로 해결|날개 싸움|핵폭탄|홍수",
	"천국 매점에서 살 것은?|아무것도 필요 없다|AI 안경|에너지드링크|핵폭탄",
	"천사들이 노래할 때는?|함께 부른다|귀를 막는다|똥누기|경적 울리기",
	"천국에서 금지된 것은?|거짓말|웃음|노래|휴식",
	"천국에서 다시 수능을 본다면?|혼자 힘으로|AI 안경으로|상품권으로|안 본다",
	"천국에서 가장 빛나는 것은?|착한 마음|금색 상품권|네온 간판|AI 안경",
	"지상의 친구에게 한마디?|\"착하게 살아\"|\"부정행위 해\"|\"핵 쏴\"|\"도망쳐\"",
	"천국 문 앞 계단은 몇 개?|셀 필요 없다|7개|50개|100개",
	"천국에서 받는 상은?|평화|1등급|자동차|돈",
	"천국에서 길을 잃으면?|천사에게 묻는다|계속 헤맨다|운다|지상으로 점프",
	"천국에서 만난 감독관에게?|반갑게 인사|도망|복수|가루 만들기",
	"천국의 첫 번째 규칙은?|서로 사랑하라|돈이 최고|뉴비 우대|1등급 우선",
	"착한 일 점수가 모자라면?|지금부터 쌓는다|위조|커닝|포기",
	"천국 하늘을 나는 방법은?|날개|자동차|핵미사일|저격수 레이저",
	"천국에서도 똥을 싸나요?|안 싼다|매일 싼다|버튼 누르면|모른다",
	"천국 문지기의 이름은?|중요하지 않다|뉴비|저격수|감독관",
	"천국의 하루는?|평온하다|바쁘다|시험만 본다|홍수가 난다",
	"천국에서 가장 많이 듣는 말은?|고마워|조용히 해|틀렸어|가루 처리",
	"지상으로 돌아갈 수 있다면?|더 착하게 살겠다|수능 다시 부정행위|핵 쏘기|저격수 되기",
	"천국 문이 열리는 조건은?|진심|돈|AI 안경|1등급",
	"천국에 오기까지 가장 어려웠던 것은?|정직하게 사는 것|저격수|홍수|면접",
	"마지막 시험으로 갈 준비가 되었나요?|네|아니요|모르겠다|AI 안경 주세요",
}

local HALLE_ROWS = {
	"외칠 준비가 되었나요?|할렐루야!|네|아니오|……",
	"천국에서도 수능을 보나요?|안 본다|본다|부정행위만 본다|모른다",
	"마지막으로 크게 외쳐 주세요!|할렐루야!|료이키 텐카이!|펑!|1등급!",
	"'할렐루야'를 외칠 때 표정은?|기쁜 표정|무표정|화난 표정|우는 표정",
	"할렐루야를 몇 번 외칠까요?|마음이 담긴 한 번|0번|100번|핵 쏠 때만",
	"'할렐루야' 다음에 어울리는 말은?|감사합니다|틀렸습니다|가루 처리|탕!",
	"천사 합창단의 박자는?|4분의 4박자|엇박|무박자|사이렌 박자",
	"할렐루야 시험의 감독관은?|아무도 없다|뉴비|저격수|매점 아주머니",
	"기쁨을 표현하는 방법은?|환하게 웃기|똥누기|핵폭탄|홍수",
	"마지막 시험에서 커닝하면?|처음부터 다시|1등급|합격|칭찬",
	"하늘에 울려 퍼지는 소리는?|노랫소리|차 경적|총소리|사이렌",
	"지금 기분은?|평화롭다|불안하다|배고프다|저격이 걱정된다",
	"두 손을 들고 외치는 이유는?|기뻐서|항복|질문|택시 부르기",
	"'아멘'과 뜻이 가까운 것은?|그렇게 되기를|안녕|잘 가|틀렸다",
	"합창이 시작되면?|함께 일어선다|누워 있는다|도망간다|AI 안경을 쓴다",
	"감사할 일 하나를 꼽는다면?|살아온 모든 날|1등급|차 50대|AI 안경",
	"천국 광장에서 할 일은?|함께 축하|부정행위|저격|홍수",
	"할렐루야 시험 제한 시간은?|없다|50분|10초|영원히 50분",
	"빛이 가장 밝은 곳은?|천국 한가운데|매점|벙커|교실",
	"마지막 시험을 통과하면?|영원한 평화|또 시험|군대|수능",
	"축하 종소리는 몇 번?|끝없이|1번|0번|저격 3발",
	"천국 잔치 음식은?|모두 함께 나눔|혼자 다 먹기|컵라면|짬밥",
	"노래 가사를 까먹으면?|흥얼거린다|커닝|AI 안경|포기",
	"기쁨의 춤을 춘다면?|다 함께|혼자 몰래|안 춘다|감독관만",
	"할렐루야를 처음 외쳐 본 소감은?|벅차다|어색하다|목 아프다|기억 안 남",
	"천국 하늘의 색은?|금빛|회색|검정|베이컨색",
	"마지막까지 함께한 것은?|나 자신|AI 안경|저격수|뉴비 차",
	"영원히 기억할 순간은?|정직했던 순간|1등급 받은 순간|폭발한 순간|똥 싼 순간",
	"할렐루야 시험의 비결은?|마음|AI 안경|1번 찍기|상품권",
	"천국 축제의 이름은?|할렐루야 축제|수능 축제|핵 축제|홍수 축제",
	"하늘에서 내리는 것은?|꽃잎|비|핵미사일|베이컨",
	"축제에서 나눠 주는 것은?|웃음|시험지|수험표|군번줄",
	"합창의 마지막 소절은?|할렐루야|가루|탕|펑",
	"모두에게 마지막 인사는?|모두 고마웠어요|다시는 안 봐|핵 쏴|도망",
	"천국에서 시험이 끝나면?|다시는 시험이 없다|또 있다|군대|면접",
	"지상에 보내는 마지막 메시지는?|정직하게 살아라|AI 안경 사라|저격 조심|홍수 조심",
	"영원한 평화를 위해 필요한 것은?|서로 사랑|핵 벙커|저격수|차 50대",
	"할렐루야 시험 점수의 의미는?|마음의 크기|돈|등급|키",
	"가장 크게 외치는 사람은?|가장 기쁜 사람|가장 키 큰 사람|감독관|저격수",
	"천국에서 '가루 처리'란?|없는 말이다|벌칙|간식|인사",
	"천국의 마지막 문 열쇠는?|감사하는 마음|AI 안경|1등급 상품권|핵 버튼",
	"마지막 시험의 감독은?|내 양심|뉴비|감독관|저격수 100명",
	"천국에 들어가서 첫 마디는?|할렐루야!|매점 어디예요?|AI 안경 주세요|료이키 텐카이!",
	"구름 위에서 넘어지면?|폭신하다|아프다|가루가 된다|폭발한다",
	"금빛 문 너머에는?|평화|시험장|군대|면접장",
	"천사가 상을 준다면?|감사히 받는다|거절|더 달라고 한다|AI 안경과 교환",
	"영원히 함께할 노래는?|기쁨의 노래|사이렌|경적|총소리",
	"마지막 문제까지 온 소감은?|뿌듯하다|지겹다|AI 안경이 필요하다|가루가 되고 싶다",
	"지금 외치고 싶은 말은?|할렐루야!|탕!|펑!|1등급!",
	"정말 마지막! 모든 시험 끝! 외쳐 주세요|할렐루야!!!|살려 줘|다시 수능|가루",
}

-- 서울대 시험용 수학 문제 자동 생성
local PRIMES = { 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73 }
local COMPOSITES = { 15, 21, 25, 27, 33, 35, 39, 45, 49, 51, 55, 57, 63, 65, 69, 77 }
local function genMathRow(r)
	local kind = r:NextInteger(1, 6)
	local q, ans, w
	if kind == 1 then
		local a, b = r:NextInteger(12, 39), r:NextInteger(12, 39)
		q, ans, w = a .. " × " .. b .. " = ?", a * b, { a * b + a, a * b - b, a * b + 10 }
	elseif kind == 2 then
		local n = r:NextInteger(5, 12)
		local v = math.floor(2 ^ n)
		q, ans, w = "2의 " .. n .. "제곱은?", v, { v / 2, v * 2, v + 2 }
	elseif kind == 3 then
		local n = r:NextInteger(3, 9)
		q = "d/dx (x^" .. n .. ") = ?"
		return q .. "|" .. n .. "x^" .. (n - 1) .. "|x^" .. (n - 1) .. "|" .. n .. "x^" .. n .. "|" .. (n - 1) .. "x^" .. (n - 2)
	elseif kind == 4 then
		local k = r:NextInteger(11, 30)
		q, ans, w = "√" .. (k * k) .. " = ?", k, { k + 1, k - 1, k * 2 }
	elseif kind == 5 then
		local n = r:NextInteger(10, 60)
		local v = n * (n + 1) / 2
		q, ans, w = "1부터 " .. n .. "까지의 합은?", v, { v + n, v - n, n * n }
	else
		local p = PRIMES[r:NextInteger(1, #PRIMES)]
		local pool = table.clone(COMPOSITES)
		local picks = {}
		for _ = 1, 3 do
			local i = r:NextInteger(1, #pool)
			table.insert(picks, table.remove(pool, i))
		end
		return "다음 중 소수는?|" .. p .. "|" .. picks[1] .. "|" .. picks[2] .. "|" .. picks[3]
	end
	return q .. "|" .. math.floor(ans) .. "|" .. math.floor(w[1]) .. "|" .. math.floor(w[2]) .. "|" .. math.floor(w[3])
end

-- "문제|정답|오답|오답|오답" 줄들 → 섞인 문제 목록 { q, a = {보기 4개}, c = 정답 번호 }
local function buildQuiz(rows, r)
	local list = {}
	for _, row in ipairs(rows) do
		local parts = string.split(row, "|")
		local opts = { parts[2], parts[3], parts[4], parts[5] }
		local order = { 1, 2, 3, 4 }
		for i = 4, 2, -1 do
			local j = r:NextInteger(1, i)
			order[i], order[j] = order[j], order[i]
		end
		local a, c = {}, 1
		for i, k in ipairs(order) do
			a[i] = opts[k]
			if k == 1 then
				c = i
			end
		end
		table.insert(list, { q = parts[1], a = a, c = c })
	end
	for i = #list, 2, -1 do
		local j = r:NextInteger(1, i)
		list[i], list[j] = list[j], list[i]
	end
	return list
end

-- 장면 1-2: 서울대 시험 (50문제)
local SNU_QUESTIONS = {}
local function sceneSNUExam()
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.fromRGB(235, 238, 245)
	eText("서울대학교 입학 시험", 0.07, Color3.fromRGB(30, 40, 80), 0.1, F.bold, 160)
	local sub = eText("합격했는데 시험을 또 본다고?", 0.035, C.muted, 0.18, F.mid, 160)
	sub.TextTransparency = 0
	local paperF = new("Frame", { Parent = endingLayer, ZIndex = 160, BackgroundColor3 = C.paper, AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.fromScale(0.6, 0.62), Position = UDim2.fromScale(0.5, 0.26) }, { corner(10), stroke() })
	local qL = text({ Parent = paperF, ZIndex = 161, Text = "", Font = F.bold, TextScaled = true, Size = UDim2.fromScale(0.9, 0.14), Position = UDim2.fromScale(0.05, 0.05) })
	local resultL = text({ Parent = paperF, ZIndex = 161, Text = "", Font = F.mid, TextScaled = true, TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.fromScale(0.9, 0.08), Position = UDim2.fromScale(0.05, 0.88) })
	local btns = {}
	for i = 1, 4 do
		local b = button({ Parent = paperF, ZIndex = 161, Text = "", Font = F.mid, TextScaled = true, BackgroundColor3 = C.paper, TextColor3 = C.text, Size = UDim2.fromScale(0.9, 0.13), Position = UDim2.fromScale(0.05, 0.24 + (i - 1) * 0.16) }, false)
		new("UIPadding", { Parent = b, PaddingTop = UDim.new(0.2, 0), PaddingBottom = UDim.new(0.2, 0) })
		btns[i] = b
	end
	local score = 0
	for n, item in ipairs(SNU_QUESTIONS) do
		qL.Text = "[" .. n .. "/" .. #SNU_QUESTIONS .. "]  " .. item.q
		for i, b in ipairs(btns) do
			b.Text = Shared.NUM[i] .. "  " .. item.a[i]
			b.BackgroundColor3 = C.paper
		end
		local chosen
		local conns = {}
		for i, b in ipairs(btns) do
			conns[i] = b.MouseButton1Click:Connect(function()
				chosen = chosen or i
			end)
		end
		repeat
			task.wait()
		until chosen
		for _, c in ipairs(conns) do
			c:Disconnect()
		end
		local ok = chosen == item.c
		if ok then
			score = score + 1
		end
		btns[item.c].BackgroundColor3 = Color3.fromRGB(210, 240, 215)
		if not ok then
			btns[chosen].BackgroundColor3 = Color3.fromRGB(250, 215, 215)
		end
		resultL.TextColor3 = ok and C.ok or C.danger
		resultL.Text = ok and "정답" or "오답"
		task.wait(0.5)
		resultL.Text = ""
	end
	paperF:Destroy()
	sub:Destroy()
	local r = eText("서울대 시험 " .. score .. " / " .. #SNU_QUESTIONS, 0.09, C.accent, 0.45, F.bold, 160)
	fadeIn(r)
	eText(score >= math.ceil(#SNU_QUESTIONS * 0.7) and "역시 1등급. 교수님이 감탄했다." or "교수님: \"수능 진짜 혼자 본 거 맞아요?\"", 0.04, Color3.fromRGB(40, 45, 60), 0.56, F.mid, 160)
	task.wait(3)
end

-- 엔딩 추가 시험들: 군대 → 인생 → (폭발) → 천국 → 할렐루야
local EXTRA_EXAMS = {
	army = {
		title = "군대 시험", sub = "면접이 끝나자마자 입대 영장이 날아왔다.",
		bg = Color3.fromRGB(95, 110, 70), titleColor = Color3.fromRGB(240, 240, 220), subColor = Color3.fromRGB(210, 220, 190),
		questions = {},
		good = "충성! 무사히 전역했다.", bad = "영창 3일… 그래도 전역은 했다.",
	},
	life = {
		title = "인생 시험", sub = "전역하고 나니 진짜 시험이 기다리고 있었다.",
		bg = Color3.fromRGB(245, 232, 210), titleColor = Color3.fromRGB(80, 50, 20), subColor = Color3.fromRGB(120, 90, 60),
		questions = {},
		good = "꽤 괜찮은 인생이었다…", bad = "후회가 많은 인생이었다…",
	},
	heaven = {
		title = "천국 시험", sub = "폭발로 죽어서 구름 위 천국 입구에 도착했다.",
		bg = Color3.fromRGB(200, 230, 255), titleColor = Color3.fromRGB(60, 90, 150), subColor = Color3.fromRGB(90, 120, 170),
		questions = {},
		good = "문지기: \"정직하군요. 들어오세요.\"", bad = "문지기: \"음… 마지막 기회를 주겠습니다.\"",
	},
	hallelujah = {
		title = "할렐루야 시험", sub = "천국에도 마지막 시험이 있었다.",
		bg = Color3.fromRGB(255, 236, 160), titleColor = Color3.fromRGB(150, 100, 0), subColor = Color3.fromRGB(170, 130, 40),
		questions = {},
		good = "할렐루야! 천국 입성!", bad = "다시 태어나서 수능부터 다시…",
	},
}

local function sceneQuiz(cfg)
	clearEnding()
	endingLayer.BackgroundColor3 = cfg.bg
	if cfg == EXTRA_EXAMS.heaven or cfg == EXTRA_EXAMS.hallelujah then
		-- 구름
		for i = 1, 7 do
			local cl = new("Frame", { Parent = endingLayer, ZIndex = 151, BackgroundColor3 = Color3.new(1, 1, 1), BackgroundTransparency = 0.2, BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.12 + (i % 3) * 0.04, 0.08), Position = UDim2.fromScale((i - 0.5) / 7, i % 2 == 0 and 0.9 or 0.96) })
			corner(1000).Parent = cl
		end
	end
	local t = eText(cfg.title, 0.08, cfg.titleColor, 0.1, F.bold, 160)
	fadeIn(t)
	local sub = eText(cfg.sub, 0.035, cfg.subColor, 0.19, F.mid, 160)
	local paperF = new("Frame", { Parent = endingLayer, ZIndex = 160, BackgroundColor3 = C.paper, AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.fromScale(0.6, 0.6), Position = UDim2.fromScale(0.5, 0.26) }, { corner(10), stroke() })
	local qL = text({ Parent = paperF, ZIndex = 161, Text = "", Font = F.bold, TextScaled = true, Size = UDim2.fromScale(0.9, 0.14), Position = UDim2.fromScale(0.05, 0.05) })
	local resultL = text({ Parent = paperF, ZIndex = 161, Text = "", Font = F.mid, TextScaled = true, TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.fromScale(0.9, 0.08), Position = UDim2.fromScale(0.05, 0.88) })
	local btns = {}
	for i = 1, 4 do
		local b = button({ Parent = paperF, ZIndex = 161, Text = "", Font = F.mid, TextScaled = true, BackgroundColor3 = C.paper, TextColor3 = C.text, Size = UDim2.fromScale(0.9, 0.13), Position = UDim2.fromScale(0.05, 0.24 + (i - 1) * 0.16) }, false)
		new("UIPadding", { Parent = b, PaddingTop = UDim.new(0.2, 0), PaddingBottom = UDim.new(0.2, 0) })
		btns[i] = b
	end
	local score = 0
	for n, item in ipairs(cfg.questions) do
		qL.Text = "[" .. n .. "/" .. #cfg.questions .. "]  " .. item.q
		for i, b in ipairs(btns) do
			b.Text = Shared.NUM[i] .. "  " .. item.a[i]
			b.BackgroundColor3 = C.paper
		end
		local chosen
		local conns = {}
		for i, b in ipairs(btns) do
			conns[i] = b.MouseButton1Click:Connect(function()
				chosen = chosen or i
			end)
		end
		repeat
			task.wait()
		until chosen
		for _, c in ipairs(conns) do
			c:Disconnect()
		end
		local ok = chosen == item.c
		if ok then
			score = score + 1
		end
		btns[item.c].BackgroundColor3 = Color3.fromRGB(210, 240, 215)
		if not ok then
			btns[chosen].BackgroundColor3 = Color3.fromRGB(250, 215, 215)
		end
		resultL.TextColor3 = ok and C.ok or C.danger
		resultL.Text = ok and "정답" or "오답"
		task.wait(0.5)
		resultL.Text = ""
	end
	paperF:Destroy()
	sub:Destroy()
	local total = #cfg.questions
	local r = eText(cfg.title .. " " .. score .. " / " .. total, 0.08, cfg.titleColor, 0.45, F.bold, 160)
	fadeIn(r)
	eText(score >= math.ceil(total * 0.7) and cfg.good or cfg.bad, 0.045, cfg.subColor, 0.56, F.mid, 160)
	task.wait(3)
	return score, total
end

-- 맨 마지막: 모든 시험 결과
local function sceneFinal(score, total)
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.fromRGB(255, 248, 220)
	local ok = score >= math.ceil(total * 0.7)
	local t = eText(ok and "할렐루야!" or "환생", 0.14, ok and Color3.fromRGB(200, 140, 0) or Color3.fromRGB(80, 80, 90), 0.38, F.bold, 160)
	fadeIn(t, 1)
	local d = eText(ok and "모든 시험을 통과하고 천국에 들어갔다. 더 이상 시험은 없다." or "다시 태어났다. 눈을 떠 보니… 수능 시험장이다.", 0.045, Color3.fromRGB(90, 80, 60), 0.52, F.mid, 160)
	fadeIn(d, 1.5)
	eText("전체 시험 " .. score .. " / " .. total, 0.04, Color3.fromRGB(120, 110, 90), 0.6, F.mid, 160)
	local back = button({ Parent = endingLayer, ZIndex = 160, Text = "다음", Font = F.bold, TextScaled = true, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.18, 0.07), Position = UDim2.fromScale(0.5, 0.78) })
	new("UIPadding", { Parent = back, PaddingTop = UDim.new(0.2, 0), PaddingBottom = UDim.new(0.2, 0) })
	local done = false
	back.MouseButton1Click:Connect(function()
		done = true
	end)
	repeat
		task.wait()
	until done
end

-- 폭발 장면
local function sceneExplosion()
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.new(1, 1, 1)
	endingLayer.BackgroundTransparency = 0
	remote:FireServer("Explode")
	-- 불꽃 원이 퍼져 나감
	local fireColors = { Color3.fromRGB(255, 240, 150), Color3.fromRGB(255, 170, 40), Color3.fromRGB(240, 80, 20), Color3.fromRGB(120, 30, 10) }
	for i, col in ipairs(fireColors) do
		local ring = new("Frame", { Parent = endingLayer, ZIndex = 155 + (5 - i), BackgroundColor3 = col, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromScale(0, 0) })
		new("UIAspectRatioConstraint", { Parent = ring, AspectRatio = 1 })
		corner(1000).Parent = ring
		TweenService:Create(ring, TweenInfo.new(0.5 + i * 0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Size = UDim2.fromScale(1.2 + i * 0.4, 1.2 + i * 0.4) }):Play()
	end
	-- 파편
	for _ = 1, 40 do
		local a = math.random() * math.pi * 2
		local d = 0.4 + math.random() * 0.4
		local bit = new("Frame", { Parent = endingLayer, ZIndex = 170, BackgroundColor3 = fireColors[math.random(1, 3)], BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(math.random(8, 20), math.random(8, 20)), Rotation = math.random(0, 360) })
		TweenService:Create(bit, TweenInfo.new(0.8 + math.random() * 0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Position = UDim2.fromScale(0.5 + math.cos(a) * d, 0.5 + math.sin(a) * d), Rotation = math.random(-720, 720), BackgroundTransparency = 1 }):Play()
	end
	local boom = eText("펑!!!", 0.25, Color3.fromRGB(255, 255, 255), 0.5, F.bold, 180)
	boom.TextStrokeTransparency = 0
	boom.TextStrokeColor3 = Color3.fromRGB(120, 20, 0)
	-- 화면 흔들기
	local t0 = os.clock()
	while os.clock() - t0 < 1.6 do
		local k = 1 - (os.clock() - t0) / 1.6
		endingLayer.Position = UDim2.fromOffset(math.random(-12, 12) * k, math.random(-12, 12) * k)
		task.wait()
	end
	endingLayer.Position = UDim2.fromOffset(0, 0)
	task.wait(0.4)
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.new(0, 0, 0)
	local dead = eText("사망", 0.12, Color3.fromRGB(200, 30, 30), 0.45, F.bold, 160)
	fadeIn(dead, 1)
	local why = eText("인생 최고의 순간에 폭발했다.", 0.04, Color3.fromRGB(180, 180, 180), 0.57, F.mid, 160)
	fadeIn(why, 1.5)
	task.wait(3.5)
end

-- 장면 2: 인줄 알았는데.......
local function sceneTwist()
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.new(0, 0, 0)
	local line = "인줄 알았는데......."
	local label = eText("", 0.09, Color3.new(1, 1, 1), 0.5, F.bold, 160)
	local chars = {}
	for _, c in utf8.codes(line) do
		table.insert(chars, utf8.char(c))
	end
	for i = 1, #chars do
		label.Text = table.concat(chars, "", 1, i)
		task.wait(i <= 6 and 0.18 or 0.32)
	end
	task.wait(1.5)
end

-- 장면 3: 회사 면접
local function sceneInterview()
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.fromRGB(225, 228, 235)
	eText("삼성 회사 면접장", 0.06, Color3.fromRGB(30, 40, 80), 0.07, F.bold, 160)
	-- 벽, 책상, 면접관 3명 (블록 캐릭터)
	eBox(Color3.fromRGB(200, 205, 215), UDim2.fromScale(1, 0.45), UDim2.fromScale(0.5, 0.6), 151)
	local suit = { Color3.fromRGB(40, 45, 60), Color3.fromRGB(30, 30, 35), Color3.fromRGB(55, 60, 80) }
	for i, x in ipairs({ 0.3, 0.5, 0.7 }) do
		eBox(suit[i], UDim2.fromScale(0.1, 0.14), UDim2.fromScale(x, 0.52), 152, 10)
		local head = eBox(Color3.fromRGB(240, 205, 175), UDim2.fromScale(0.06, 0.1), UDim2.fromScale(x, 0.39), 153, 40)
		new("UIAspectRatioConstraint", { Parent = head, AspectRatio = 1 })
		local eyes = text({ Parent = head, ZIndex = 154, Text = "-  -", Font = F.bold, TextScaled = true, TextColor3 = Color3.fromRGB(30, 30, 30), TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.fromScale(1, 0.4), Position = UDim2.fromScale(0, 0.3) })
		eyes.TextTransparency = 0
	end
	eBox(Color3.fromRGB(120, 85, 55), UDim2.fromScale(0.62, 0.08), UDim2.fromScale(0.5, 0.6), 155, 6)

	local qPanel = new("Frame", { Parent = endingLayer, ZIndex = 160, BackgroundColor3 = Color3.new(1, 1, 1), AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.fromScale(0.7, 0.34), Position = UDim2.fromScale(0.5, 0.63) }, { corner(12), stroke() })
	local qLabel2 = text({ Parent = qPanel, ZIndex = 161, Text = "", Font = F.bold, TextScaled = true, TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.fromScale(0.92, 0.2), Position = UDim2.fromScale(0.04, 0.05) })
	local btns = {}
	for i = 1, 3 do
		local b = button({ Parent = qPanel, ZIndex = 161, Text = "", Font = F.mid, TextScaled = true, BackgroundColor3 = C.sub, TextColor3 = C.text, Size = UDim2.fromScale(0.9, 0.19), Position = UDim2.fromScale(0.05, 0.3 + (i - 1) * 0.23) }, false)
		new("UIPadding", { Parent = b, PaddingTop = UDim.new(0.2, 0), PaddingBottom = UDim.new(0.2, 0) })
		btns[i] = b
	end

	local score, confessed = 0, false
	for _, item in ipairs(INTERVIEW) do
		qLabel2.Text = "면접관: \"" .. item.q .. "\""
		local chosen = nil
		local conns = {}
		for i, b in ipairs(btns) do
			b.Text = item.a[i][1]
			conns[i] = b.MouseButton1Click:Connect(function()
				chosen = item.a[i][2]
			end)
		end
		repeat
			task.wait()
		until chosen ~= nil
		for _, c in ipairs(conns) do
			c:Disconnect()
		end
		if chosen == "confess" then
			confessed = true
			break
		end
		score = score + chosen
	end
	qPanel:Destroy()

	local title2, desc
	if confessed then
		title2, desc = "불합격", "면접관: \"부정행위 자백 감사합니다.\" 서울대 합격도 취소되었다."
	elseif score >= 3 then
		title2, desc = "최종 합격!", "축하합니다. 내일부터 출근하세요."
	else
		title2, desc = "불합격", "면접관: \"다음 기회에…\" 내년에 다시 도전하자."
	end
	local r1 = eText(title2, 0.1, confessed and C.danger or (score >= 3 and C.ok or C.danger), 0.72, F.bold, 160)
	local r2 = eText(desc, 0.04, Color3.fromRGB(40, 45, 60), 0.82, F.mid, 160)
	fadeIn(r1)
	fadeIn(r2, 1)
	local back = button({ Parent = endingLayer, ZIndex = 160, Text = "확인", Font = F.bold, TextScaled = true, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.18, 0.07), Position = UDim2.fromScale(0.5, 0.92) })
	new("UIPadding", { Parent = back, PaddingTop = UDim.new(0.2, 0), PaddingBottom = UDim.new(0.2, 0) })
	local done = false
	back.MouseButton1Click:Connect(function()
		done = true
	end)
	repeat
		task.wait()
	until done
end

-- 진짜 마지막: "아.... 꿈이였구나" → 고등학교 수업 시간
local function sceneDream()
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.new(0, 0, 0)
	local line = "아.... 꿈이였구나"
	local label = eText("", 0.08, Color3.new(1, 1, 1), 0.5, F.bold, 160)
	local chars = {}
	for _, c in utf8.codes(line) do
		table.insert(chars, utf8.char(c))
	end
	for i = 1, #chars do
		label.Text = table.concat(chars, "", 1, i)
		task.wait((chars[i] == ".") and 0.35 or 0.15)
	end
	task.wait(2)

	-- 고등학교 수업 시간 (교실 그림)
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.fromRGB(232, 226, 205)
	local board = eBox(Color3.fromRGB(31, 77, 58), UDim2.fromScale(0.6, 0.32), UDim2.fromScale(0.5, 0.42), 152, 6)
	stroke(Color3.fromRGB(120, 90, 60), 6).Parent = board
	text({ Parent = board, ZIndex = 153, Text = "3교시  수학\nf(x) = x²  →  f'(x) = 2x", Font = F.bold, TextScaled = true, TextColor3 = Color3.fromRGB(235, 245, 238), TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.fromScale(0.9, 0.8), Position = UDim2.fromScale(0.05, 0.1) })
	-- 선생님 (블록 그림)
	eBox(Color3.fromRGB(60, 70, 110), UDim2.fromScale(0.07, 0.16), UDim2.fromScale(0.85, 0.62), 154, 8)
	local th = eBox(Color3.fromRGB(240, 205, 175), UDim2.fromScale(0.05, 0.09), UDim2.fromScale(0.85, 0.47), 155, 40)
	new("UIAspectRatioConstraint", { Parent = th, AspectRatio = 1 })
	-- 책상 줄
	for row = 0, 1 do
		for col = 0, 4 do
			eBox(Color3.fromRGB(150, 115, 80), UDim2.fromScale(0.12, 0.06), UDim2.fromScale(0.14 + col * 0.18, 0.78 + row * 0.12), 153, 4)
		end
	end
	-- 엎드려 자던 나 (가운데 앞자리)
	local me = eBox(Color3.fromRGB(76, 110, 245), UDim2.fromScale(0.06, 0.05), UDim2.fromScale(0.5, 0.73), 156, 8)
	me.Name = "Me"
	local bubble = new("Frame", { Parent = endingLayer, ZIndex = 160, BackgroundColor3 = Color3.new(1, 1, 1), AnchorPoint = Vector2.new(1, 1), Size = UDim2.fromScale(0.36, 0.12), Position = UDim2.fromScale(0.82, 0.4) }, { corner(14), stroke() })
	text({ Parent = bubble, ZIndex = 161, Text = "거기! 수업 시간에 자면 어떡해!\n수능 얼마 안 남았다!", Font = F.bold, TextScaled = true, TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.fromScale(0.9, 0.8), Position = UDim2.fromScale(0.05, 0.1) })
	local cap = eText("고등학교 3학년 · 수업 시간", 0.05, Color3.fromRGB(80, 60, 40), 0.1, F.bold, 160)
	fadeIn(cap)
	local back = button({ Parent = endingLayer, ZIndex = 160, Text = "수업 듣기", Font = F.bold, TextScaled = true, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.18, 0.07), Position = UDim2.fromScale(0.5, 0.95) })
	new("UIPadding", { Parent = back, PaddingTop = UDim.new(0.2, 0), PaddingBottom = UDim.new(0.2, 0) })
	local done = false
	back.MouseButton1Click:Connect(function()
		done = true
	end)
	repeat
		task.wait()
	until done

	-- 내 화면의 교실 칠판도 수업 시간으로 바뀜 (나만 보임)
	local w = workspace:FindFirstChild("SuneungWorld")
	local bb = w and w:FindFirstChild("Blackboard")
	local sg = bb and bb:FindFirstChildOfClass("SurfaceGui")
	local tl = sg and sg:FindFirstChildOfClass("TextLabel")
	if tl then
		tl.Text = "3교시 수학\n수업 중에 졸지 맙시다"
	end
end

-------------------------------------------------------------------
-- 영화 같은 엔딩 크레딧: 한국 수능 부정행위
-------------------------------------------------------------------
local function playCredits()
	local cg = new("ScreenGui", { Name = "Credits", ResetOnSpawn = false, IgnoreGuiInset = true, DisplayOrder = 100, Parent = player:WaitForChild("PlayerGui") })
	local bg = new("Frame", { Parent = cg, BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1), ZIndex = 1 })
	-- 영화 화면 같은 위아래 검은 띠
	local barTop = new("Frame", { Parent = cg, BackgroundColor3 = Color3.new(0, 0, 0), BorderSizePixel = 0, Size = UDim2.fromScale(1, 0), ZIndex = 10 })
	local barBot = new("Frame", { Parent = cg, BackgroundColor3 = Color3.new(0, 0, 0), BorderSizePixel = 0, AnchorPoint = Vector2.new(0, 1), Position = UDim2.fromScale(0, 1), Size = UDim2.fromScale(1, 0), ZIndex = 10 })
	TweenService:Create(barTop, TweenInfo.new(1.2), { Size = UDim2.fromScale(1, 0.12) }):Play()
	TweenService:Create(barBot, TweenInfo.new(1.2), { Size = UDim2.fromScale(1, 0.12) }):Play()
	task.wait(1.4)
	TweenService:Create(bg, TweenInfo.new(1.5), { BackgroundTransparency = 0 }):Play()
	task.wait(1.6)

	local function big(str, size, color, y, font)
		return text({ Parent = cg, ZIndex = 5, Text = str, Font = Enum.Font.GothamBlack, TextStrokeTransparency = 0.6, TextScaled = true, TextColor3 = color, TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.8, size), Position = UDim2.fromScale(0.5, y) })
	end
	-- 제목
	local title = big("한국 수능 부정행위", 0.14, Color3.new(1, 1, 1), 0.46)
	local subtitle = big("— 한 수험생의 길고 긴 하루 —", 0.04, Color3.fromRGB(180, 180, 180), 0.58, F.mid)
	title.TextTransparency, subtitle.TextTransparency = 1, 1
	TweenService:Create(title, TweenInfo.new(2), { TextTransparency = 0 }):Play()
	task.wait(1)
	TweenService:Create(subtitle, TweenInfo.new(2), { TextTransparency = 0 }):Play()
	task.wait(4)
	TweenService:Create(title, TweenInfo.new(1.5), { TextTransparency = 1 }):Play()
	TweenService:Create(subtitle, TweenInfo.new(1.5), { TextTransparency = 1 }):Play()
	task.wait(1.6)
	title:Destroy()
	subtitle:Destroy()

	-- 올라가는 자막
	local lines = {
		{ "출연", true },
		{ "수험생 · " .. player.DisplayName },
		{ "뉴비 감독관 · 뉴비 감독관" },
		{ "저격수 · 저격수 100명" },
		{ "매점 아주머니 · 매점 아주머니" },
		{ "부정행위 전문점 사장 · 전문점 사장" },
		{ "강화 장인 · 강화 장인" },
		{ "도로의 차 · 베이컨" },
		{ "주차장의 차 · 뉴비 차 50대" },
		{ "" },
		{ "특별 출연", true },
		{ "AI 안경 (성공률 100%)" },
		{ "1등급 상품권" },
		{ "핵폭탄 · 홍수 · 똥" },
		{ "" },
		{ "등장한 시험", true },
		{ "수능 · 서울대 · 면접 · 군대 · 인생 · 천국 · 할렐루야" },
		{ "K부대 훈련 25개" },
		{ "" },
		{ "촬영 장소", true },
		{ "교실 · 도로 · 매점 · 핵 벙커 · K부대" },
		{ "" },
		{ "제작", true },
		{ "K스튜디오 & 클로드" },
		{ "" },
		{ "이 게임의 모든 부정행위는 꿈입니다." },
		{ "실제 시험에서는 절대 따라 하지 마세요." },
		{ "" },
		{ "플레이해 주셔서 감사합니다", true },
	}
	local roll = new("Frame", { Parent = cg, BackgroundTransparency = 1, ZIndex = 5, AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.fromScale(0.7, 0.06 * #lines), Position = UDim2.fromScale(0.5, 1) })
	for i, l in ipairs(lines) do
		text({ Parent = roll, ZIndex = 6, Text = l[1], Font = l[2] and Enum.Font.GothamBlack or F.bold, TextScaled = true, TextColor3 = l[2] and Color3.fromRGB(255, 215, 120) or Color3.fromRGB(230, 230, 230), TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.new(1, 0, 1 / #lines, -10), Position = UDim2.fromScale(0, (i - 1) / #lines) })
	end
	local dur = 22
	TweenService:Create(roll, TweenInfo.new(dur, Enum.EasingStyle.Linear), { Position = UDim2.fromScale(0.5, -0.06 * #lines) }):Play()
	task.wait(dur)
	roll:Destroy()

	-- THE END
	local the = big("THE END", 0.16, Color3.new(1, 1, 1), 0.5)
	the.TextTransparency = 1
	TweenService:Create(the, TweenInfo.new(2), { TextTransparency = 0 }):Play()
	task.wait(4)
	TweenService:Create(the, TweenInfo.new(1.5), { TextTransparency = 1 }):Play()
	TweenService:Create(bg, TweenInfo.new(1.5), { BackgroundTransparency = 1 }):Play()
	TweenService:Create(barTop, TweenInfo.new(1.5), { Size = UDim2.fromScale(1, 0) }):Play()
	TweenService:Create(barBot, TweenInfo.new(1.5), { Size = UDim2.fromScale(1, 0) }):Play()
	task.wait(1.6)
	cg:Destroy()
end

-------------------------------------------------------------------
-- K부대 (군대 게임 모드) 화면
-------------------------------------------------------------------
local armyMode = false
local armyGui = new("ScreenGui", { Name = "ArmyUI", ResetOnSpawn = false, IgnoreGuiInset = true, Enabled = false, Parent = player:WaitForChild("PlayerGui") })
local armyHud = new("Frame", { Parent = armyGui, BackgroundColor3 = Color3.fromRGB(40, 48, 32), BackgroundTransparency = 0.1, AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.fromScale(0.42, 0.13), Position = UDim2.fromScale(0.5, 0.02) }, { corner(12), stroke(Color3.fromRGB(150, 160, 110), 2) })
local armyRank = text({ Parent = armyHud, Text = "이병", Font = F.bold, TextScaled = true, TextColor3 = Color3.fromRGB(255, 220, 90), TextXAlignment = Enum.TextXAlignment.Center, Size = UDim2.fromScale(0.25, 0.8), Position = UDim2.fromScale(0.02, 0.1) })
local armyMission = text({ Parent = armyHud, Text = "", Font = F.bold, TextScaled = true, TextColor3 = Color3.fromRGB(235, 240, 220), Size = UDim2.fromScale(0.68, 0.3), Position = UDim2.fromScale(0.3, 0.06) })
local armyDesc = text({ Parent = armyHud, Text = "", Font = F.mid, TextScaled = true, TextColor3 = Color3.fromRGB(255, 230, 150), Size = UDim2.fromScale(0.68, 0.26), Position = UDim2.fromScale(0.3, 0.38) })
local armyProg = text({ Parent = armyHud, Text = "", Font = F.mid, TextScaled = true, TextColor3 = Color3.fromRGB(190, 200, 160), Size = UDim2.fromScale(0.68, 0.24), Position = UDim2.fromScale(0.3, 0.7) })
-- 다음에 갈 곳 표시 (내 화면에만 보이는 빛기둥)
local armyMarker = Instance.new("Part")
armyMarker.Anchored = true
armyMarker.CanCollide = false
armyMarker.CanQuery = false
armyMarker.CanTouch = false
armyMarker.Material = Enum.Material.Neon
armyMarker.Color = Color3.fromRGB(80, 200, 255)
armyMarker.Transparency = 0.45
armyMarker.Size = Vector3.new(4, 30, 4)
armyMarker.Shape = Enum.PartType.Block
text({ Parent = armyGui, Text = "마우스 왼쪽 클릭: 사격   ·   파란 빛기둥: 가야 할 곳   ·   훈련 25개: 이병 → 일병 → 상병 → 병장 → 전역", Font = F.mid, TextScaled = true, TextColor3 = Color3.new(1, 1, 1), TextStrokeTransparency = 0.4, TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 1), Size = UDim2.fromScale(0.6, 0.03), Position = UDim2.fromScale(0.5, 0.98) })
-- 조준점
local cross = new("Frame", { Parent = armyGui, BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromOffset(24, 24), Position = UDim2.fromScale(0.5, 0.5) })
new("Frame", { Parent = cross, BackgroundColor3 = Color3.new(1, 1, 1), BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromOffset(2, 24), Position = UDim2.fromScale(0.5, 0.5) })
new("Frame", { Parent = cross, BackgroundColor3 = Color3.new(1, 1, 1), BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromOffset(24, 2), Position = UDim2.fromScale(0.5, 0.5) })
local mouse = player:GetMouse()
RunService.RenderStepped:Connect(function()
	if armyMode then
		cross.Position = UDim2.fromOffset(mouse.X, mouse.Y + 36)
	end
end)
local armyToast = text({ Parent = armyGui, Text = "", Font = F.bold, TextScaled = true, TextColor3 = Color3.new(1, 1, 1), BackgroundColor3 = Color3.fromRGB(30, 35, 25), BackgroundTransparency = 0.2, TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0), Size = UDim2.fromScale(0.5, 0.05), Position = UDim2.fromScale(0.5, 0.17), Visible = false })
local armyToastId = 0
local function armyToastShow(msg)
	armyToastId = armyToastId + 1
	local my = armyToastId
	armyToast.Text = msg
	armyToast.Visible = true
	task.delay(2.5, function()
		if armyToastId == my then
			armyToast.Visible = false
		end
	end)
end

UserInputService.InputBegan:Connect(function(input, processed)
	if processed or not armyMode then
		return
	end
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		local char = player.Character
		if char and char:FindFirstChild("소총") then
			remote:FireServer("Shoot", mouse.Hit.Position)
		end
	end
end)

-- 입대 장면
local function sceneEnlist()
	clearEnding()
	endingLayer.BackgroundColor3 = Color3.fromRGB(40, 48, 32)
	local t1 = eText("그리고 몇 년 뒤…", 0.06, Color3.fromRGB(220, 225, 200), 0.3, F.mid, 160)
	fadeIn(t1)
	task.wait(1.5)
	local t2 = eText("입대 날이 왔다. 배치받은 곳은… K부대.", 0.07, Color3.fromRGB(255, 220, 90), 0.45, F.bold, 160)
	fadeIn(t2)
	task.wait(1)
	local go = button({ Parent = endingLayer, ZIndex = 160, Text = "입대하기", Font = F.bold, TextScaled = true, BackgroundColor3 = Color3.fromRGB(90, 110, 60), AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.2, 0.08), Position = UDim2.fromScale(0.5, 0.7) })
	new("UIPadding", { Parent = go, PaddingTop = UDim.new(0.2, 0), PaddingBottom = UDim.new(0.2, 0) })
	local done = false
	go.MouseButton1Click:Connect(function()
		done = true
	end)
	repeat
		task.wait()
	until done
end

-- 전역 화면
local armyEndLayer = new("Frame", { Parent = armyGui, BackgroundColor3 = Color3.fromRGB(40, 48, 32), Size = UDim2.fromScale(1, 1), ZIndex = 50, Visible = false })
text({ Parent = armyEndLayer, ZIndex = 51, Text = "전역을 축하합니다!", Font = F.bold, TextScaled = true, TextColor3 = Color3.fromRGB(255, 220, 90), TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.7, 0.12), Position = UDim2.fromScale(0.5, 0.35) })
local armyEndDesc = text({ Parent = armyEndLayer, ZIndex = 51, Text = "", Font = F.mid, TextScaled = true, TextColor3 = Color3.fromRGB(220, 225, 200), TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.7, 0.045), Position = UDim2.fromScale(0.5, 0.48) })
local armyBack = button({ Parent = armyEndLayer, ZIndex = 51, Text = "학교로 돌아가기", Font = F.bold, TextScaled = true, BackgroundColor3 = Color3.fromRGB(90, 110, 60), AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.24, 0.08), Position = UDim2.fromScale(0.5, 0.65) })
new("UIPadding", { Parent = armyBack, PaddingTop = UDim.new(0.2, 0), PaddingBottom = UDim.new(0.2, 0) })
armyBack.MouseButton1Click:Connect(function()
	armyEndLayer.Visible = false
	armyGui.Enabled = false
	armyMode = false
	UserInputService.MouseIconEnabled = true
	-- 영화처럼 엔딩 크레딧을 보고 학교로
	playCredits()
	root.Visible = true
	remote:FireServer("LeaveArmy")
end)

local function startArmy()
	armyMode = true
	root.Visible = false
	armyGui.Enabled = true
	armyHud.Visible = true
	remote:FireServer("EnlistArmy")
end

local function playEnding()
	root.Visible = false
	endingLayer.Visible = true
	-- 매번 새로 섞은 50문제씩
	local r = Random.new()
	local snuRows = table.clone(SNU_ROWS)
	while #snuRows < 50 do
		table.insert(snuRows, genMathRow(r))
	end
	SNU_QUESTIONS = buildQuiz(snuRows, r)
	EXTRA_EXAMS.army.questions = buildQuiz(ARMY_ROWS, r)
	EXTRA_EXAMS.life.questions = buildQuiz(LIFE_ROWS, r)
	EXTRA_EXAMS.heaven.questions = buildQuiz(HEAVEN_ROWS, r)
	EXTRA_EXAMS.hallelujah.questions = buildQuiz(HALLE_ROWS, r)
	sceneUniversity()
	sceneSNUExam()
	sceneTwist()
	sceneInterview()
	local total, max = 0, 0
	for _, key in ipairs({ "army", "life" }) do
		local a, b = sceneQuiz(EXTRA_EXAMS[key])
		total, max = total + a, max + b
	end
	sceneExplosion()
	for _, key in ipairs({ "heaven", "hallelujah" }) do
		local a, b = sceneQuiz(EXTRA_EXAMS[key])
		total, max = total + a, max + b
	end
	sceneFinal(total, max)
	sceneDream()
	sceneEnlist()
	clearEnding()
	endingLayer.Visible = false
	setExamMode(false)
	status.Text = "고등학교 수업 시간"
	-- 마지막: K부대 군대 게임 시작
	startArmy()
end

remote.OnClientEvent:Connect(function(action, data, extra, extra2)
	if action == "Question" then
		if not inExam then
			setExamMode(true)
		end
		modal.Visible = false
		qNum, qTotal = data.num, data.total
		if data.num == 1 then
			timeLeft, suspicion = Shared.TIME_LIMIT, 0
		end
		paperNum.Text = data.seat .. "번 좌석"
		qLabel.Text = data.num .. ".  " .. data.text
		picked = nil
		paperMsg.Text = ""
		for i, b in ipairs(choiceBtns) do
			b.Text = Shared.NUM[i] .. "   " .. tostring(data.options[i])
			b.BackgroundColor3 = C.paper
			b.UIStroke.Color = C.line
			b.UIStroke.Thickness = 1
		end
		hintLabel.Text = ""
		updateStatus()
	elseif action == "Timer" then
		timeLeft, suspicion = data, extra
		updateStatus()
	elseif action == "CheatStart" then
		cheatDur = data
		cheatingUntil = os.clock() + data
		progBg.Visible = true
		hintLabel.TextColor3 = C.muted
		hintLabel.Text = "시도 중…"
	elseif action == "Hint" or action == "CheatCancel" then
		cheatingUntil = nil
		progBg.Visible = false
		if action == "Hint" then
			hintLabel.TextColor3 = C.ok
			hintLabel.Text = data
			if type(extra) == "table" and extra.ans then
				local c = cheats[selected]
				showCheatView(c and c.name or "", c and c.copy, extra.ans, extra)
			end
		end
	elseif action == "Domain" then
		cheatingUntil = nil
		progBg.Visible = false
		showDomain(data)
	elseif action == "Log" then
		table.insert(logs, 1, data)
		if #logs > 3 then
			table.remove(logs)
		end
		logLabel.Text = table.concat(logs, "\n")
	elseif action == "Away" then
		away = data
		leaveBtn.Text = away and "자리로 돌아가기" or "몰래 나가기"
		paper.Visible = not away
		cheatBtn.Visible = not away
		if away then
			toast("감독관 시야(빨간 빛)를 피해 문으로 나가세요. 돌아오면 자리 근처에서 버튼을 누르세요.")
		end
	elseif action == "NukeWarn" then
		toast(data .. " 님이 핵폭탄을 발사했습니다! " .. extra .. "초 후 도착! 교실 뒤 왼쪽 핵 벙커로 대피!")
		local warn = text({ Parent = gui, ZIndex = 190, Text = "핵폭탄 접근 중", Font = F.bold, TextScaled = true, TextColor3 = Color3.fromRGB(255, 60, 60), TextStrokeTransparency = 0, TextXAlignment = Enum.TextXAlignment.Center, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromScale(0.6, 0.1), Position = UDim2.fromScale(0.5, 0.3) })
		task.spawn(function()
			for _ = 1, extra * 2 do
				warn.Visible = not warn.Visible
				task.wait(0.5)
			end
			warn:Destroy()
		end)
	elseif action == "FloodWarn" then
		toast(data .. " 님이 홍수를 일으켰습니다! 교실 뒤 사다리로 지붕에 대피!")
	elseif action == "NukeBoom" then
		local flash = new("Frame", { Parent = gui, ZIndex = 195, BackgroundColor3 = Color3.new(1, 1, 1), Size = UDim2.fromScale(1, 1) })
		TweenService:Create(flash, TweenInfo.new(2.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { BackgroundTransparency = 1 }):Play()
		task.delay(2.6, function()
			flash:Destroy()
		end)
	elseif action == "Army" then
		armyRank.Text = data.rank
		armyMission.Text = data.mission
		armyDesc.Text = data.desc or ""
		armyProg.Text = data.progress ~= "" and ("진행: " .. data.progress) or ""
		if data.marker then
			armyMarker.Position = data.marker + Vector3.new(0, 15, 0)
			armyMarker.Parent = workspace
		else
			armyMarker.Parent = nil
		end
	elseif action == "ArmyEnd" then
		armyHud.Visible = false
		armyMarker.Parent = nil
		armyEndDesc.Text = "병장 " .. data .. ", K부대 훈련 25개를 모두 마치고 전역했습니다. 충성!"
		armyEndLayer.Visible = true
	elseif action == "Toast" and armyMode then
		armyToastShow(data)
	elseif action == "Toast" then
		toast(data)
	elseif action == "Inventory" then
		renderBag(data)
	elseif action == "Money" then
		showMoney(data)
	elseif action == "OpenProShop" then
		proMoney.Text = "가진 돈 " .. data .. "원"
		proBought = extra or proBought
		local c = cheats[selected]
		if c then
			customName.Text = c.name .. "  ·  " .. Shared.doubled(Shared.proPrice(c.name), proBought) .. "원"
		else
			customName.Text = "왼쪽에서 물건을 고르세요"
		end
		refreshProButtons()
		proShop.Visible = true
	elseif action == "Upgrades" then
		perkLv = data.perks or {}
		gearLv = data.gear or {}
		for i, c in ipairs(cheats) do
			cheats[i] = Shared.makeCheat(c.name, owned[c.name], gearLv[c.name])
		end
		renderCheats()
		refreshUpShop()
	elseif action == "OpenUpShop" then
		upMoney.Text = "가진 돈 " .. data .. "원"
		refreshUpShop()
		upShop.Visible = true
	elseif action == "Owned" then
		proBought = extra2 or proBought
		owned = {}
		for _, n in ipairs(data) do
			owned[n] = true
		end
		for i, c in ipairs(cheats) do
			cheats[i] = Shared.makeCheat(c.name, owned[c.name], gearLv[c.name])
		end
		if extra then
			addCheat(extra)
		end
		renderCheats()
		refreshProButtons()
	elseif action == "OpenShop" then
		showMoney(data)
		shop.Visible = true
	elseif action == "End" then
		cheatingUntil = nil
		away = false
		progBg.Visible = false
		paper.Visible = false
		if data.reason == "flood" then
			mTitle.Text = "홍수"
			mGrade.Text = "익사"
			mGrade.TextColor3 = C.danger
			mDesc.Text = string.format("시험장이 물에 잠겼다.\n푼 문제 %d개 중 %d개 정답", data.answered, data.score)
		elseif data.reason == "nuke" then
			mTitle.Text = "핵폭탄"
			mGrade.Text = "전멸"
			mGrade.TextColor3 = C.danger
			mDesc.Text = string.format("누군가 핵폭탄을 쐈다. 시험장이 사라졌다.\n푼 문제 %d개 중 %d개 정답", data.answered, data.score)
		elseif data.reason == "sniper" then
			mTitle.Text = "저격당함"
			mGrade.Text = "실격"
			mGrade.TextColor3 = C.danger
			mDesc.Text = string.format("몰래 나갔다가 지붕 위 저격수에게 맞았습니다.\n푼 문제 %d개 중 %d개 정답", data.answered, data.score)
		elseif data.reason == "car" then
			mTitle.Text = "교통사고"
			mGrade.Text = "실격"
			mGrade.TextColor3 = C.danger
			mDesc.Text = string.format("시험 중 몰래 나갔다가 차에 치였습니다.\n푼 문제 %d개 중 %d개 정답", data.answered, data.score)
		elseif data.reason == "caught" then
			mTitle.Text = "부정행위 적발"
			mGrade.Text = "실격"
			mGrade.TextColor3 = C.danger
			mDesc.Text = string.format("가루가 되었습니다.\n푼 문제 %d개 중 %d개 정답", data.answered, data.score)
		else
			mTitle.Text = data.timeUp and "시험 시간 종료" or "시험 종료"
			mGrade.Text = data.grade .. "등급"
			mGrade.TextColor3 = C.accent
			mDesc.Text = string.format("%d문제 중 %d개 정답", Shared.TOTAL_Q, data.score)
			if data.grade == 1 then
				-- 1등급 엔딩
				task.spawn(playEnding)
				return
			end
		end
		modal.Visible = true
	end
end)

updateStatus()
